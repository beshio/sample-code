//
//  DownloadViewController.swift
//  downLoader
//
//  Created by Tomonao Yuzawa on 2017/06/25.
//  Copyright © 2017年 beshio. All rights reserved.
//

import UIKit
import CoreTelephony
import AudioToolbox

// fire local notification
// https://stackoverflow.com/questions/6340664/delete-a-particular-local-notification/32389835#32389835
// https://stackoverflow.com/questions/10652274/dismiss-an-already-delivered-uilocalnotification
//
func fireFileDownloadNotification(_ msg: String) {
	removeFiledownloadNotification()
	let localNotification = UILocalNotification()
	localNotification.alertBody = msg
	localNotification.soundName = UILocalNotificationDefaultSoundName
	UIApplication.shared.presentLocalNotificationNow(localNotification)
	let notificationData = NSKeyedArchiver.archivedData(withRootObject: localNotification)
	UserDefaults.standard.set(notificationData, forKey: "fileDownloaded")
	let state = UIApplication.shared.applicationState
	if (state == .active) {
		loggingMessage("* fireFileDownloadNotification: active")
	} else {
		loggingMessage("* fireFileDownloadNotification: not active")
	}
}

// remove fired notification
//
func removeFiledownloadNotification() {
	let userDefaults = UserDefaults.standard
	if let existingNotificationData = userDefaults.object(forKey: "fileDownloaded") as? NSData, let existingNotification = NSKeyedUnarchiver.unarchiveObject(with: existingNotificationData as Data) as? UILocalNotification {
		// Cancel notification if scheduled, delete it from notification center if already delivered
		UIApplication.shared.cancelLocalNotification(existingNotification)
		// Clean up
		userDefaults.removeObject(forKey: "fileDownloaded")
	}
}

// handle initial map download to start with
//
class DownloadViewController: UIViewController {
	@IBOutlet weak var message0: UILabel!
	@IBOutlet weak var message0top: NSLayoutConstraint!
	@IBOutlet weak var message1: UILabel!
	@IBOutlet weak var message1top: NSLayoutConstraint!
	@IBOutlet weak var message2: UILabel!
	@IBOutlet weak var useMblCommMessage: UILabel!
	@IBOutlet weak var useMobileCommSwitch: UISwitch!
	@IBOutlet weak var downloadProgress: UIProgressView!
	@IBOutlet weak var downloadButton: UIButton!
	@IBOutlet weak var progressTitle: UILabel!
	@IBOutlet weak var downloadStopButton: UIButton!
	@IBOutlet weak var downloadProgressBar: UIProgressView!
	@IBOutlet weak var deleteDownloadFilesButton: UIButton!
	@IBOutlet weak var emulateBkgExpirationButton: UIButton!
	@IBOutlet weak var createSessionWithoutFlagButton: UISwitch!
	@IBOutlet weak var notifyBkgndTaskExpirationSwitch: UISwitch!
	@IBOutlet weak var notifyUserWithoutFlagSwitch: UISwitch!
	@IBOutlet weak var noDeleteFlagFileSwitch: UISwitch!
	
	var initState = 0
	var useMobileComm = false
	var notificationRegistered = false
	var createSessionWithoutFlag = false
	var notifyUserWithoutFlag = false
	var notifyBkgndTaskExpirationFlag = false
	var entireInitialMapInfo: [MapDownloadInfo] = []
	var mapDownloadInfo: [MapDownloadInfo]! = nil
	var mapDownloaderObj: MapDownloaderObj! = nil
	var totalInitialFiles = 0
	var msglines = 0
	var dispErrMsg = false
	var cellularData: CTCellularData! = nil
	var cellularRestrictredState = CTCellularDataRestrictedState.restrictedStateUnknown
	var doUpdateUIFlag = false	// true if observer set

	let dwldMsg1 = "Download all of low scale maps. Total download size is about 56MB."
	let dwldMsg2 = "Couldn't download all of maps. Try again. If outdoors, enable mobile network."
	let onDwldMsg = "Downloading now. You can switch to other apps, but it may take more time; if notification enabled, will let you know when finished."
	let dwldMsg3 = "All of maps have been downloaded. To test again, delete downlaoded files."
	let completeMsg = "Congrats! All of files downloaded."

	// key value changed
	//
	override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
		if (keyPath == "doUpdateUI") {
			// session done
#if DEBUG
			print("observeValue: doUpdateUI")
#endif
			let flagFileExists = MapDownloaderObj.checkAndRemoveFlagFile(remove: true)
			let appDelegate = UIApplication.shared.delegate as! AppDelegate
			if (!appDelegate.doUpdateUI) {
				return
			}
			appDelegate.removeObserver(self, forKeyPath: "doUpdateUI")
			doUpdateUIFlag = false
			// update UI
			mapDownloadInfo = nil
			mapDownloadInfo = createInitialDownloadFileList(entireInitialInfo: entireInitialMapInfo)
			DispatchQueue.main.async {
				self.emulateBkgExpirationButton.isEnabled = false
			}
			if (mapDownloadInfo.count != 0) {
				// some error on download
				loggingMessage("* doUpdateUI: some error")
				dispErrMsg = true
				DispatchQueue.main.async(execute: {
					self.message2.text = self.dwldMsg2
					self.message2.alpha = 1.0
					self.message2.isHidden = false
					self.setDownloadView()
				})
			} else {
				DispatchQueue.main.async(execute: {
					self.message2.text = self.completeMsg
					self.message2.alpha = 1.0
					self.message2.isHidden = false
					self.dispDwdCompletion()
				})
			}
			// call completion handler
			if let completionHandler = appDelegate.backgroundSessionCompletionHandler {
				appDelegate.backgroundSessionCompletionHandler = nil
				DispatchQueue.main.async {
					completionHandler()
				}
			}
			if (!flagFileExists) {
				if UserDefaults.standard.object(forKey: "notifyUserWithoutFlag") != nil {
					let notifyAnyway = UserDefaults.standard.bool(forKey: "notifyUserWithoutFlag")
					if (!notifyAnyway) {
						// this will result in memory waste
						return
					}
				}
				// this will result in zombie for users
			}
			fireFileDownloadNotification("Map download completed. Go back to downLoader.")
			return
		} else if (keyPath == "remainedCount") {
			// remained download count changed
			let mdobj = object as! MapDownloaderObj
			let remainedCount = mdobj.remainedCount
			let progress = Float(totalInitialFiles-remainedCount) / Float(totalInitialFiles)
			DispatchQueue.main.async(execute: {
				self.downloadProgress.setProgress(progress, animated: true)
			})
		} else if (keyPath == "runOutOfTime") {
			// background task time expired
			let mdobj = object as! MapDownloaderObj
			if (!mdobj.runOutOfTime || !notifyBkgndTaskExpirationFlag) {
				return
			}
			fireFileDownloadNotification("Background download expired. Pls make app foreground to continue.")
		}
	}

	// display download completion
	//
	func dispDwdCompletion() {
		deleteDownloadFilesButton.isEnabled = true
		Network.reachability = nil
		initState = 2
		message0.text = dwldMsg3
		message0.alpha = 0.0
		message0.isHidden = false
		useMblCommMessage.isHidden = true
		useMobileCommSwitch.isHidden = true
		UIView.animate(withDuration: 0.4,
			animations: {() -> Void in
				self.message0.alpha = 1.0
				self.message1.alpha = 0.0
				self.useMobileCommSwitch.alpha = 0.0
				self.progressTitle.alpha = 0.0
				self.downloadStopButton.alpha = 0.0
				self.downloadProgressBar.alpha = 0.0
			},
			completion: {(Bool) -> Void in
				self.message1.isHidden = true
				self.useMobileCommSwitch.isHidden = true
				self.progressTitle.isHidden = true
				self.downloadStopButton.isHidden = true
				self.downloadProgressBar.isHidden = true
			}
		)
	}
	
	// flip notify completion w/o flag
	//
	@IBAction func notifyUserWithoutFlagTapped(_ sw: UISwitch) {
		let prevFlag = notifyUserWithoutFlag
		notifyUserWithoutFlag = sw.isOn
		if (prevFlag != notifyUserWithoutFlag) {
			UserDefaults.standard.set(notifyUserWithoutFlag, forKey: "notifyUserWithoutFlag")
		}
	}
	
	// flip create session w/o flag
	//
	@IBAction func createSessionWithoutFlagTapped(_ sw: UISwitch) {
		let prevFlag = createSessionWithoutFlag
		createSessionWithoutFlag = sw.isOn
		if (prevFlag != createSessionWithoutFlag) {
			UserDefaults.standard.set(createSessionWithoutFlag, forKey: "createSessionWithoutFlag")
		}
	}

	// flip to use mobile communication
	//
	@IBAction func useMobileCommTapped(_ sw: UISwitch) {
		useMobileComm = sw.isOn
	}

	// flip to notify background task expiration
	//
	@IBAction func notifyBkgndTaskExpirationTapped(_ sw: UISwitch) {
		let prevFlag = notifyBkgndTaskExpirationFlag
		notifyBkgndTaskExpirationFlag = sw.isOn
		if (prevFlag != notifyBkgndTaskExpirationFlag) {
			UserDefaults.standard.set(notifyBkgndTaskExpirationFlag, forKey: "notifyBkgndTaskExpirationFlag")
		}
	}
	
	// open setting. http://blog.personal-factory.com/2015/12/21/swift-open-setteing-app/
	//
	func openMySetting() {
		UIApplication.shared.openURL(NSURL(string: UIApplicationOpenSettingsURLString)! as URL)
	}
	
	// check if network is ok
	//
	func checkNetworkConnection() -> Bool {
#if (arch(i386) || arch(x86_64)) && os(iOS)
		return true
#endif
#if DEBUG && true
		if cellularData.restrictedState == .restrictedStateUnknown {
			print("unknown")
		} else if (cellularData.restrictedState == .restricted) {
			print("restricted")
		} else if (cellularData.restrictedState == .notRestricted) {
			print("not restricted")
		}
#endif
		// at first, check network connection
		guard let status = Network.reachability?.status else { return false }
		switch status {
		case .unreachable:
			let alert: UIAlertController!
			if (cellularData.restrictedState == .restricted) {
				alert = UIAlertController(title: "Download", message: "No network connection found. Enable to use mobile network w/ setting.", preferredStyle: .alert)
				alert.addAction(UIAlertAction(title: "Setting", style: .default, handler: {action in self.openMySetting()}))
				alert.addAction(UIAlertAction(title: "No thanks", style: .default, handler: nil))
			} else {
				alert = UIAlertController(title: "Download", message: "No network connection found. Possibly in airplane mode. Check it.", preferredStyle: .alert)
				alert.addAction(UIAlertAction(title: "Gotcha", style: .default, handler: nil))
			}
			present(alert, animated: true, completion: nil)
			return false
		case .wifi:
			break
		case .wwan:
			if (!useMobileComm) {
				let alert: UIAlertController!
				if (cellularData.restrictedState == .restricted) {
					alert = UIAlertController(title: "Download", message: "No WiFi connection. Enable to use mobile network w/ setting.", preferredStyle: .alert)
					alert.addAction(UIAlertAction(title: "Setting", style: .default, handler: {action in self.openMySetting()}))
					alert.addAction(UIAlertAction(title: "No thanks", style: .default, handler: nil))
				} else {
					alert = UIAlertController(title: "Download", message: "No WiFi connection. W/o mobile network, can't start dowload.", preferredStyle: .alert)
					alert.addAction(UIAlertAction(title: "Use it", style: .default, handler: {action in
						self.useMobileCommSwitch.setOn(true, animated: false)
						self.useMobileComm = true
					}))
					alert.addAction(UIAlertAction(title: "No thanks", style: .default, handler: nil))
				}
				present(alert, animated: true, completion: nil)
				return false
			}
		}
		return true
	}
	
	// download start button tapped
	//
	@IBAction func downloadTapped(_ sender: Any) {
		if (!checkNetworkConnection()) {
			return
		}
		let appDelegate = UIApplication.shared.delegate as! AppDelegate
		appDelegate.doUpdateUI = false
		if (!doUpdateUIFlag) {
			doUpdateUIFlag = true
			appDelegate.addObserver(self, forKeyPath: "doUpdateUI", options: [.new], context: nil)
		}
		appDelegate.viewDidAppearFlag = false
		appDelegate.urlSessionDidFinishEventsFlag = false
		if (!notificationRegistered) {
			let settings = UIUserNotificationSettings(types: [.alert, .sound], categories: nil)
			UIApplication.shared.registerUserNotificationSettings(settings)
			notificationRegistered = true
		}
		deleteDownloadFilesButton.isEnabled = false
		emulateBkgExpirationButton.isEnabled = true
		progressTitle.alpha = 0.0
		progressTitle.isHidden = false
		downloadStopButton.alpha = 0.0
		downloadStopButton.isHidden = false
		downloadProgressBar.alpha = 0.0
		downloadProgressBar.isHidden = false
		downloadProgress.setProgress(0.0, animated: false)
		message0.text = onDwldMsg
		message0.sizeToFit()
		message0.alpha = 0.0
		message0.isHidden = false
		var numDownloadFiles = 0
		for i in 0 ..< mapDownloadInfo.count {
			numDownloadFiles += mapDownloadInfo[i].downloadFiles.count
		}
		let progress = Float(totalInitialFiles-numDownloadFiles) / Float(totalInitialFiles)
		downloadProgress.setProgress(progress, animated: false)
		UIView.animate(withDuration: 0.4,
			animations: {() -> Void in
				self.downloadButton.alpha = 0.0
				self.progressTitle.alpha = 1.0
				self.downloadStopButton.alpha = 1.0
				self.downloadProgressBar.alpha = 1.0
				self.message0.alpha = 1.0
				self.message1.alpha = 0.0
				self.message2.alpha = 0.0
				self.useMblCommMessage.alpha = 0.0
				self.useMobileCommSwitch.alpha = 0.0
			},
			completion: {(Bool) -> Void in
				self.downloadButton.isHidden = true
				self.downloadButton.alpha = 1.0
				self.message1.isHidden = true
				self.message1.alpha = 1.0
				self.message2.isHidden = true
				self.message2.alpha = 1.0
				self.useMblCommMessage.isHidden = true
				self.useMobileCommSwitch.isHidden = true
			}
		)
		_ = storeEntireTileList(entireTileList: entireInitialMapInfo)
		mapDownloaderObj = MapDownloaderObj.sharedInstance
		appDelegate.mapDownloaderObj = mapDownloaderObj
		mapDownloaderObj.mapDownloadInfo = mapDownloadInfo
		mapDownloaderObj.useCellular = useMobileComm
		mapDownloaderObj.addObserver(self, forKeyPath: "remainedCount", options: [.new], context: nil)
		mapDownloaderObj.addObserver(self, forKeyPath: "runOutOfTime", options: [.new], context: nil)
		mapDownloaderObj.startDownloadTask()
		mapDownloadInfo = nil
	}
	
	// setup view for download screen
	//
	func setDownloadView() {
		downloadButton.alpha = 0.0
		downloadButton.isHidden = false
		message1.alpha = 0.0
		message1.isHidden = false
		useMblCommMessage.alpha = 0.0
		useMblCommMessage.isHidden = false
		useMobileCommSwitch.alpha = 0.0
		useMobileCommSwitch.isHidden = false
		if (dispErrMsg) {
			message2.alpha = 0.0
			message2.isHidden = false
			dispErrMsg = false
		}
		UIView.animate(withDuration: 0.4,
			animations: {() -> Void in
			self.progressTitle.alpha = 0.0
			self.downloadStopButton.alpha = 0.0
			self.downloadProgressBar.alpha = 0.0
			self.downloadButton.alpha = 1.0
			self.message1.alpha = 1.0
			self.message0.alpha = 0.0
			self.message2.alpha = 1.0
			self.useMblCommMessage.alpha = 1.0
			self.useMobileCommSwitch.alpha = 1.0
		}, completion: {(Bool) -> Void in
			self.progressTitle.isHidden = true
			self.progressTitle.alpha = 1.0
			self.downloadStopButton.isHidden = true
			self.downloadStopButton.alpha = 1.0
			self.downloadProgressBar.alpha = 1.0
			self.downloadProgressBar.isHidden = true
			self.message0.alpha = 1.0
			self.message0.isHidden = true
		})
	}
	
	// stop download
	//
	@IBAction func downloadStopTapped(_ sender: Any) {
		mapDownloaderObj.removeObserver(self, forKeyPath: "remainedCount")
		mapDownloaderObj.removeObserver(self, forKeyPath: "runOutOfTime")
		mapDownloaderObj.stopDownloadTask(removeFlagFile: true)
		mapDownloaderObj = nil
		mapDownloadInfo = nil
		mapDownloadInfo = createInitialDownloadFileList(entireInitialInfo: entireInitialMapInfo)
		if (mapDownloadInfo.count == 0) {
			// download done
			dispDwdCompletion()
		} else {
			setDownloadView()
		}
		deleteDownloadFilesButton.isEnabled = true
		emulateBkgExpirationButton.isEnabled = false
	}
	
	// setup layout constraints
	//
	func setupLayoutConstraints() {
		let collection = UITraitCollection(verticalSizeClass: .regular)
		if (traitCollection.containsTraits(in: collection)) {
			// portrait
			message0top.constant = 40.0
			message1top.constant = 40.0
		} else {
			message0top.constant = 20.0
			message1top.constant = 20.0
		}
	}
	
	// display log file contents
	//
	@IBAction func showLogTapped(_ sender: Any) {
		let storyboard: UIStoryboard = UIStoryboard(name: "ShowLogFile", bundle: Bundle.main)
		let showLogFileViewController = storyboard.instantiateInitialViewController() as! ShowLogFileViewController
		let backButton = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
		navigationItem.backBarButtonItem = backButton
		navigationController!.pushViewController(showLogFileViewController, animated: true)
	}
	
	// layout subviews
	//
	override func viewDidLayoutSubviews() {
		super.viewDidLayoutSubviews()
		setupLayoutConstraints()
	}
	
	// view will appear. hide nav bar
	//
	override func viewWillAppear(_ animated: Bool) {
		navigationController?.setNavigationBarHidden(true, animated: animated)
		self.navigationItem.hidesBackButton = true
		super.viewWillAppear(animated)
	}

	// view loaded
	//
	override func viewDidAppear(_ animated: Bool) {
		super.viewDidAppear(animated)
		loggingMessage("* viewDidAppear")
		let appDelegate = UIApplication.shared.delegate as! AppDelegate
		appDelegate.asem.wait()
		appDelegate.viewDidAppearFlag = true
		let mapDownloaderObj = appDelegate.mapDownloaderObj
		if (mapDownloaderObj != nil /*&& mapDownloaderObj!.relaunch*/ && appDelegate.urlSessionDidFinishEventsFlag) {
			// we already have obj, should be relaunch, and session already done. update UI here
			appDelegate.urlSessionDidFinishEventsFlag = false
			mapDownloadInfo = nil
			mapDownloadInfo = createInitialDownloadFileList(entireInitialInfo: entireInitialMapInfo)
			if (mapDownloadInfo.count != 0) {
				// some error on download
				loggingMessage("* doUpdateUI: some error")
				dispErrMsg = true
				message2.text = self.dwldMsg2
				setDownloadView()
			} else {
				dispErrMsg = true
				message2.text = self.completeMsg
				dispDwdCompletion()
			}
			// see if we have flag file
			let flagFileExists = MapDownloaderObj.checkAndRemoveFlagFile(remove: true)
			if (!flagFileExists) {
				loggingMessage("* viewDidAppear: no flag file")
			}
			// now, we should be in background. let user know w/ local notification
			let state = UIApplication.shared.applicationState
			if (state == .active) {
				// this shouldn't happen, but it does happen. it should be BUG of iOS...
				AudioServicesPlaySystemSoundWithCompletion(1032, nil)  // suspense. http://iphonedevwiki.net/index.php/AudioServices
				loggingMessage("* applicationState active !!!")
				var notifyAnyway = flagFileExists
				if (!flagFileExists) {
					if UserDefaults.standard.object(forKey: "notifyUserWithoutFlag") != nil {
						notifyAnyway = UserDefaults.standard.bool(forKey: "notifyUserWithoutFlag")
						loggingMessage("* no flag file but alert")
					}
				}
				if (notifyAnyway) {
					DispatchQueue.main.async {
						let alertController = UIAlertController(title: "downLoader", message: "Download completed !", preferredStyle: .alert)
						alertController.addAction(UIAlertAction(title: "Gotcha", style: .cancel, handler: nil))
						self.present(alertController, animated: false, completion: nil)
					}
				} else {
					loggingMessage("* no flag file ==> no alert")
				}
				if let completionHandler = appDelegate.backgroundSessionCompletionHandler {
					// call completion handler
					loggingMessage("* call completionHandler")
					appDelegate.backgroundSessionCompletionHandler = nil
					DispatchQueue.main.async {
						completionHandler()
					}
				}
			} else {
				loggingMessage("* applicationState not active (good)")
				var notifyAnyway = flagFileExists
				if (!flagFileExists) {
					if UserDefaults.standard.object(forKey: "notifyUserWithoutFlag") != nil {
						notifyAnyway = UserDefaults.standard.bool(forKey: "notifyUserWithoutFlag")
						loggingMessage("* no flag file but notification")
					}
				}
				if (notifyAnyway) {
					DispatchQueue.main.async {
						fireFileDownloadNotification("Map download completed. Go back to downLoader.")
					}
				} else {
					loggingMessage("* no flag file ==> no notification")
				}
				if let completionHandler = appDelegate.backgroundSessionCompletionHandler {
					loggingMessage("* call completionHandler")
					appDelegate.backgroundSessionCompletionHandler = nil
					DispatchQueue.main.async {
						completionHandler()
					}
				}
			}
		} else {
			// yet download obj or could be no obj. we set observer for both cases
			doUpdateUIFlag = true
			appDelegate.addObserver(self, forKeyPath: "doUpdateUI", options: [.new], context: nil)
		}
		appDelegate.asem.signal()
	}
	
	// log clear button tapped
	//
	@IBAction func clearLogButton(_ sender: Any) {
		clearLogging()
		let libdir = NSSearchPathForDirectoriesInDomains(.libraryDirectory, .userDomainMask, true)[0]
		loggingMessage("* \(libdir)")
	}
	
	// file delete button tapped
	//
	@IBAction func deleteDownloadedFilesTapped(_ sender: Any) {
		if (Network.reachability == nil) {
			Network.reachability = try! Reachability(hostname: "cyberjapandata.gsi.go.jp")
		}
		let downloadDir = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true)[0] + "/download"
		try? FileManager().removeItem(atPath: downloadDir)
		mapDownloadInfo = nil
		mapDownloadInfo = createInitialDownloadFileList(entireInitialInfo: entireInitialMapInfo)
		if (initState == 2) {
			initState = 1
			useMblCommMessage.alpha = 0.0
			useMblCommMessage.isHidden = false
			useMobileCommSwitch.alpha = 0.0
			useMobileCommSwitch.isHidden = false
			message1.alpha = 0.0
			message1.isHidden = false
			message1.text = dwldMsg1
			downloadButton.alpha = 0.0
			downloadButton.isHidden = false
			UIView.animate(withDuration: 0.4,
				animations: {() -> Void in
				self.message0.alpha = 0.0
				self.useMblCommMessage.alpha = 1.0
				self.useMobileCommSwitch.alpha = 1.0
				self.message1.alpha = 1.0
				self.downloadButton.alpha = 1.0
				self.message2.alpha = 0.0
			}, completion: {(Bool) -> Void in
				self.message0.isHidden = true
				self.message2.isHidden = true
			})
		}
	}
	
	// leave/remove file at exit
	//
	var noDeleteFlagFile = false

	@IBAction func leaveFlagButtonTapped(_ sw: UISwitch) {
		let prevFlag = noDeleteFlagFile
		noDeleteFlagFile = sw.isOn
		let appDelegate = UIApplication.shared.delegate as! AppDelegate
		appDelegate.removeFlagFileAtExit = !noDeleteFlagFile
		if (prevFlag != noDeleteFlagFile) {
			UserDefaults.standard.set(notifyBkgndTaskExpirationFlag, forKey: "noDeleteFlagFileSwitch")
		}
	}
	
	// create flag file
	//
	@IBAction func createFlagFileTapped(_ sender: Any) {
		let dwldFlagFile = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true)[0] + "/download/downloadFlag.dat"
		let fd = open(dwldFlagFile, O_CREAT)
		if (fd != -1) {
			close(fd)
		}
	}

	// I will die. thanks !
	//
	@IBAction func crashAppTapped(_ sender: Any) {
		let alert: UIAlertController!
		alert = UIAlertController(title: "Crash !", message: "Are you ok to crash this app in 5 sec ? You need to have started download to test this in background. Note if under debugger, the app merely stops w/ it.", preferredStyle: .alert)
		alert.addAction(UIAlertAction(title: "Do it!", style: .destructive, handler: {action in Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.handleKillAtTot(_:)), userInfo: nil, repeats: false)}))
		alert.addAction(UIAlertAction(title: "Not now", style: .default, handler: nil))
		present(alert, animated: true, completion: nil)
	}
	
	func handleKillAtTot(_ time: Timer) {
		youAreDone()
	}
	
	// emulate background task expiration
	//
	@IBAction func emulateBkgExpirationTapped(_ sender: Any) {
		let alert: UIAlertController!
		alert = UIAlertController(title: "Bkgnd Task Expiration", message: "After you hit Do it, chanage the app to background. You need to have started download to test this.", preferredStyle: .alert)
		alert.addAction(UIAlertAction(title: "Do it!", style: .destructive, handler: {action in Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.handleBkgTaskExpirationAtTot(_:)), userInfo: nil, repeats: false)}))
		alert.addAction(UIAlertAction(title: "Not now", style: .default, handler: nil))
		present(alert, animated: true, completion: nil)
	}
	
	func handleBkgTaskExpirationAtTot(_ time: Timer) {
		mapDownloaderObj = MapDownloaderObj.sharedInstance
		mapDownloaderObj.emulateBkgTaskExpiration()
	}
	
#if DEBUG && false
	// test being killed by os
	//
	var memAarray: [UnsafeMutablePointer<Int>] = []

	// run other memory hungry apps so that this app is killed. gdb will show mem issue message. nice!
	//
	func eatMemory() {
		let mem128M = 134217728/MemoryLayout<Int>.size/2
		for _ in 0 ..< 31 {
			let mem = UnsafeMutablePointer<Int>.allocate(capacity: mem128M)
			for j in 0 ..< mem128M {
				mem[j] = 0
			}
			memAarray.append(mem)
		}
	}
#endif

	// view loaded
	//
	override func viewDidLoad() {
		super.viewDidLoad()
		let libdir = NSSearchPathForDirectoriesInDomains(.libraryDirectory, .userDomainMask, true)[0]
		loggingMessage("* \(libdir)")
		loggingMessage("* viewDidLoad")
#if DEBUG
		print(libdir)
#endif
#if DEBUG && false
		eatMemory()
#endif
		if UserDefaults.standard.object(forKey: "createSessionWithoutFlag") != nil {
			createSessionWithoutFlag = UserDefaults.standard.bool(forKey: "createSessionWithoutFlag")
			if (createSessionWithoutFlag) {
				createSessionWithoutFlagButton.isOn = true
			}
		}
		if UserDefaults.standard.object(forKey: "notifyUserWithoutFlag") != nil {
			notifyUserWithoutFlag = UserDefaults.standard.bool(forKey: "notifyUserWithoutFlag")
			if (notifyUserWithoutFlag) {
				notifyUserWithoutFlagSwitch.isOn = true
			}
		}
		if UserDefaults.standard.object(forKey: "notifyBkgndTaskExpirationFlag") != nil {
			notifyBkgndTaskExpirationFlag = UserDefaults.standard.bool(forKey: "notifyUserWithoutFlag")
			if (notifyBkgndTaskExpirationFlag) {
				notifyBkgndTaskExpirationSwitch.isOn = true
			}
		}
		if UserDefaults.standard.object(forKey: "noDeleteFlagFileSwitch") != nil {
			noDeleteFlagFile = UserDefaults.standard.bool(forKey: "noDeleteFlagFileSwitch")
			if (noDeleteFlagFile) {
				noDeleteFlagFileSwitch.isOn = true
			}
		}
		// create initial file list
		entireInitialMapInfo = createInitialFileList()
		for i in 0 ..< entireInitialMapInfo.count {
			totalInitialFiles += entireInitialMapInfo[i].downloadFiles.count
		}
		loggingMessage("* totalFiles = \(totalInitialFiles)")
		mapDownloadInfo = createInitialDownloadFileList(entireInitialInfo: entireInitialMapInfo)
#if DEBUG && false
		var downloadCount = 0
		for i in 0 ..< mapDownloadInfo.count {
			downloadCount += mapDownloadInfo[i].downloadFiles.count
		}
		loggingMessage("* downloadFiles = \(downloadCount)")
#endif
		if (mapDownloadInfo.count != 0) {
			// need download
			message1.isHidden = false
			message1.text = dwldMsg1
			downloadButton.isHidden = false
			useMblCommMessage.isHidden = false
			useMobileCommSwitch.isHidden = false
		} else {
			// we've done all of download already
			initState = 2
			message0.text = dwldMsg3
			message0.isHidden = false
			useMblCommMessage.isHidden = true
			useMobileCommSwitch.isHidden = true
		}
		useMobileCommSwitch.setOn(false, animated: false)
		Network.reachability = try! Reachability(hostname: "cyberjapandata.gsi.go.jp")
		// http://koze.hatenablog.jp/entry/2015/06/18/220000
		cellularData = CTCellularData()
		cellularData.cellularDataRestrictionDidUpdateNotifier = {(CTCellularDataRestrictedState) -> Void in
			self.cellularRestrictredState = CTCellularDataRestrictedState
			if (CTCellularDataRestrictedState == .restrictedStateUnknown) {
				DispatchQueue.main.async {
					self.useMobileCommSwitch.setOn(false, animated: false)
					self.useMobileCommSwitch.isEnabled = false
					self.useMobileComm = false
				}
#if DEBUG && false
				print("unknown")
#endif
			} else if (CTCellularDataRestrictedState == .restricted) {
				DispatchQueue.main.async {
					self.useMobileCommSwitch.setOn(false, animated: false)
					self.useMobileCommSwitch.isEnabled = false
					self.useMobileComm = false
				}
#if DEBUG && false
				print("restricted")
#endif
			} else if (CTCellularDataRestrictedState == .notRestricted) {
				DispatchQueue.main.async {
					self.useMobileCommSwitch.isEnabled = true
				}
#if DEBUG && false
				print("not restricted")
#endif
			}
		}
	}
	
	deinit {
#if DEBUG
		print("deinit: InitialDownloadViewController")
#endif
		for i in 0 ..< entireInitialMapInfo.count {
			entireInitialMapInfo[i].coltbl.deallocate(capacity: 256)
		}
	}
}

// file format of entire file list
/*
UInt32 numScales	//number of zoom scales
UInt32 zsVal0		// e.g., 6, 8, 9, 10, ..., 17
UInt32 numTiles0
UInt32 xtnum[0]
UInt32 ytnum[0]
...
UInt32 xtnum[numTiles0-1]
UInt32 ytnum[numTiles0-1]
UInt32 zsVal1
UInt32 numTiles1
...
UInt32 ytnum[numTiles1-1]
...
*/

// store entire map list including files already downloaded
//
func storeEntireTileList(entireTileList: [MapDownloadInfo]) -> Bool {
	let fileManager = FileManager()
	let fileDir = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true)[0] + "/download"
	try? fileManager.createDirectory(atPath: fileDir, withIntermediateDirectories: false, attributes: nil)
	let entireTileListFile = fileDir + "/entireTileList.dat"
	let fp = fopen(entireTileListFile, "w")
	if (fp == nil) {
		return false
	}
	// data conversion. https://stackoverflow.com/questions/28680589/how-to-convert-an-int-into-nsdata-in-swift <= not using
	var numScales = UInt32(entireTileList.count)
	fwrite(&numScales, MemoryLayout<UInt32>.size, 1, fp)
	for i in 0 ..< entireTileList.count {
		let tileList = entireTileList[i]
		let urlPrefix = tileList.urlPrefix!
		// find zoom scale string
		var offset = -2
		var zsVal: UInt32 = 0
		while (true) {
			// find "/" from last of string
			let idx = urlPrefix.index(urlPrefix.endIndex, offsetBy: offset)
			if (urlPrefix[idx] == "/") {
				let zsStr = urlPrefix.substring(with: urlPrefix.index(idx, offsetBy: 1) ..< urlPrefix.index(urlPrefix.endIndex, offsetBy: -1))
				zsVal = UInt32(zsStr)!
				break
			}
			offset -= 1
		}
		fwrite(&zsVal, MemoryLayout<UInt32>.size, 1, fp)
		// write number of tiles
		let numTiles = tileList.downloadFiles.count
		var numTiles32 = UInt32(numTiles)
		fwrite(&numTiles32, MemoryLayout<UInt32>.size, 1, fp)
		// write y and x tile numbers
		for j in 0 ..< numTiles {
			let dstFile = tileList.dstFiles[j]
			// find "-"
			offset = 1
			var yt: UInt32 = 0, xt: UInt32 = 0
			while (true) {
				let idx = dstFile.index(dstFile.startIndex, offsetBy: offset)
				if (dstFile[idx] == "-") {
					let ystr = dstFile.substring(to: dstFile.index(dstFile.startIndex, offsetBy: offset))
					yt = UInt32(ystr)!
					let xstr = dstFile.substring(from: dstFile.index(dstFile.startIndex, offsetBy: offset+1))
					xt = UInt32(xstr)!
					break
				}
				offset += 1
			}
			fwrite(&xt, MemoryLayout<UInt32>.size, 1, fp)
			fwrite(&yt, MemoryLayout<UInt32>.size, 1, fp)
		}
	}
	fclose(fp)
	return true
}

// create initial download file list by checking already downloaded files. existing files are excluded
//
func createInitialDownloadFileList(entireInitialInfo: [MapDownloadInfo]) -> [MapDownloadInfo] {
	// remove already downloaded file from list
	let fileManager = FileManager()
	let downloadDir = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true)[0] + "/download/"
	var mapDownloadInfo: [MapDownloadInfo] = []
	for didx in 0 ..< entireInitialInfo.count {
		let mapDwldInfo = entireInitialInfo[didx]
		var downloadInitialInfo: MapDownloadInfo! = nil
		for fidx in 0 ..< mapDwldInfo.downloadFiles.count {
			var dwldFile = downloadDir + mapDwldInfo.dstDir + "/"
			dwldFile += mapDwldInfo.dstFiles[fidx]
#if true
			var fileFound = fileManager.fileExists(atPath: dwldFile + ".png")
			if (!fileFound) {
				fileFound = fileManager.fileExists(atPath: dwldFile + ".p8")
			}
#else
			var fileFound = fileManager.fileExists(atPath: dwldFile + ".p8")
#endif
			if (!fileFound) {
				fileFound = fileManager.fileExists(atPath: dwldFile + ".p4")
			}
			if (!fileFound) {
				fileFound = fileManager.fileExists(atPath: dwldFile + ".p2")
			}
			if (!fileFound) {
				fileFound = fileManager.fileExists(atPath: dwldFile + ".p1")
			}
			if (!fileFound) {
				if (downloadInitialInfo == nil) {
					downloadInitialInfo = MapDownloadInfo()
					downloadInitialInfo.urlPrefix = mapDwldInfo.urlPrefix
					downloadInitialInfo.urlSuffix = mapDwldInfo.urlSuffix
					downloadInitialInfo.dstDir = mapDwldInfo.dstDir
				}
				downloadInitialInfo.downloadFiles.append(mapDwldInfo.downloadFiles[fidx])
				downloadInitialInfo.dstFiles.append(mapDwldInfo.dstFiles[fidx])
			}
		}
		if (downloadInitialInfo != nil) {
			downloadInitialInfo.coltbl = mapDwldInfo.coltbl
			mapDownloadInfo.append(downloadInitialInfo)
		}
	}
	return mapDownloadInfo
}

// create chiriin file list to be downloaded initially
//
func createInitialFileList() -> [MapDownloadInfo] {
	let mapRootDir = NSSearchPathForDirectoriesInDomains(.libraryDirectory, .userDomainMask, true)[0] + "/mapdata"
	let mapIniFile = mapRootDir + "/Chiriin/mapdesc.ini"
	let descStr = UnsafeMutablePointer<Int8>.allocate(capacity: Int(PATH_MAX))
	GetPrivateProfileStr("GENERAL", "downLoadDispScale", "", descStr, PATH_MAX, mapIniFile)
	let downLoadDispScale = Int(atoi(descStr))
	GetPrivateProfileStr("GENERAL", "numScales", "", descStr, PATH_MAX, mapIniFile)
	let numScales = Int(atoi(descStr))
	// create map tile list to download from downLoadDispScale ... numScales-1
	let mapCtrl = CreateMapCtrl(mapRootDir)
	let mgrp = CreateMapGrp(mapCtrl, "Chiriin")
	var mapDwldInfo: [MapDownloadInfo] = []
	var totalTilesToDownload = 0
	for i in stride(from: numScales-1, to: downLoadDispScale-1, by: -1) {
#if DEBUG
		loggingMessage("* creating file list: \(i)")
#endif
		let mapDwdInfoCurrent = MapDownloadInfo()
		// see this for url naming. http://maps.gsi.go.jp/development/siyou.html
		GetPrivateProfileStr("CHIRIIN", "zoomScale\(i)", "", descStr, PATH_MAX, mapIniFile)
		let zsVal = atoi(descStr)
		mapDwdInfoCurrent.urlPrefix = "http://cyberjapandata.gsi.go.jp/xyz/std/\(zsVal)/"
		mapDwdInfoCurrent.urlSuffix = ".png"
		mapDwdInfoCurrent.dstDir = "\(i)"
		// get tile number list
		GetPrivateProfileStr("CHIRIIN", "minXtile\(i)", "", descStr, PATH_MAX, mapIniFile)
		let minXtile = Int(atoi(descStr))
		GetPrivateProfileStr("CHIRIIN", "maxYtile\(i)", "", descStr, PATH_MAX, mapIniFile)
		let maxYtile = Int(atoi(descStr))
		let mobj = CreateMapObjWithNoMapdata(mgrp, Int32(i))
		// get color table
		let colorTbl = RequestColorTable(mobj)
		mapDwdInfoCurrent.coltbl = UnsafeMutablePointer<UInt32>.allocate(capacity: 256)
		memcpy(mapDwdInfoCurrent.coltbl, colorTbl, MemoryLayout<UInt32>.size*256)
		// get tile info
		var tlist: UnsafeMutablePointer<UInt32>? = nil
		let nt = RequestEntireValidMapTileInfo(mobj, &tlist, 1)
		let tileList = tlist!
		DestroyMapObj(mobj)
		let ntiles = Int(nt)
		totalTilesToDownload += ntiles
		// set tile numbers in array
		for j in 0 ..< ntiles {
			let xt = minXtile + Int(tileList[j]&0xffff)
			let yt = maxYtile - Int(tileList[j]>>16)
			mapDwdInfoCurrent.downloadFiles.append("\(xt)/\(yt)")
			mapDwdInfoCurrent.dstFiles.append("\(yt)-\(xt)")
#if DEBUG && false
			print(mapDwdInfoCurrent.downloadFiles[j])
#endif
		}
		mapDwldInfo.append(mapDwdInfoCurrent)
		free(tlist)
#if DEBUG
		loggingMessage("* created file list: \(i)")
#endif
	}
	descStr.deallocate(capacity: Int(PATH_MAX))
	DestroyMapCtrl(mapCtrl)
	return mapDwldInfo
}

// setup map folders. return 0 if really 1st time, 1 if need to download files, 2 if ready to go
//
func setupMapFolders() -> Int {
	// create map root folder
	let fileManager = FileManager()
	let mapDir = NSSearchPathForDirectoriesInDomains(.libraryDirectory, .userDomainMask, true)[0] + "/mapdata"
	// see if where we are
	let mapStatFile = "file://" + mapDir + "/Chiriin/mapstat.txt"
	// "1": map directory created, "2": mandatory files downloaded, ready to go
	let fstat: String!
	do {
		let fdata = try Data(contentsOf: URL(string: mapStatFile)!)
		fstat = String(data: fdata, encoding: String.Encoding(rawValue: String.Encoding.utf8.rawValue))!
	} catch _ {
		fstat = "0"
	}
	if (fstat == "2") {
		// we are ready
		return 2
	} else if (fstat == "1") {
		// need to download mandatory files
		return 1
	}
	do {
		try fileManager.createDirectory(atPath: mapDir, withIntermediateDirectories: false, attributes: nil)
	} catch _ {
		// error should be dup, which is ok
	}
	// exclude map root folder from itune backup. string to url =>
	// https://stackoverflow.com/questions/32666765/how-to-exclude-file-from-backup-with-swift-2/43761689#43761689
	let fileUrl = NSURL(string: "file://" + mapDir)!
	do {
		try fileUrl.setResourceValue(true, forKey: URLResourceKey.isExcludedFromBackupKey)
	} catch _ {
#if DEBUG
		// just sanity check. should not happen
		print("failed!")
#endif
	}
	// get map desc file in bundle
	let mainBundle = Bundle.main
	let bundleMapDir = mainBundle.bundlePath + "/mapdata"
	let contents = try? fileManager.contentsOfDirectory(atPath: bundleMapDir)
	let dirNames = contents! as [String]
	let cnt = dirNames.count
#if DEBUG
	print(mapDir)
#endif
	for i in (0 ..< cnt) {
		if (dirNames[i].hasPrefix(".")) {
			continue;
		}
		let mapDataDir = mapDir + "/" + dirNames[i]
		try? fileManager.createDirectory(atPath: mapDataDir, withIntermediateDirectories: false, attributes: nil)
		let fileUrl = NSURL(string: "file://" + mapDataDir)!
		try? fileUrl.setResourceValue(true, forKey: URLResourceKey.isExcludedFromBackupKey)
		let bundleMapDataDir = bundleMapDir + "/" + dirNames[i]
		// read desc file and create directories and setup mandatory files
		// note symlionk donesn't always work, and hardlink to bundle not possible, so, we need workaround
		// https://stackoverflow.com/questions/23016864/is-it-possible-to-create-hard-links-to-files-in-an-ios-application-bundle
		// copy map desc file since it's small
		let descFileDst = mapDataDir + "/mapdesc.ini"
		let descFileSrc = bundleMapDataDir + "/mapdesc.ini"
		do {
			try fileManager.copyItem(atPath: descFileSrc, toPath: descFileDst)
		} catch _ {
			// should be dup, delete and copy
			try? fileManager.removeItem(atPath: descFileDst)
			try? fileManager.copyItem(atPath: descFileSrc, toPath: descFileDst)
		}
		let descFileUrl = NSURL(string: "file://" + descFileDst)!
		try? descFileUrl.setResourceValue(true, forKey: URLResourceKey.isExcludedFromBackupKey)
		// create map data file dirs
		let mapContents = try? fileManager.contentsOfDirectory(atPath: bundleMapDataDir)
		let mapScales = mapContents! as [String]
		let scaleCnt = mapScales.count
		for j in (0 ..< scaleCnt) {
			if (mapScales[j].hasPrefix(".")) {
				continue;
			}
			let bundleMapScaleDir = bundleMapDataDir + "/" + mapScales[j]
			let attr = try! fileManager.attributesOfItem(atPath: bundleMapScaleDir) as NSDictionary?
			if (attr?.fileType() != "NSFileTypeDirectory") {
				continue
			}
			// create map directory
			let mapScaleDir = mapDataDir + "/" + mapScales[j]
			try? fileManager.createDirectory(atPath: mapScaleDir, withIntermediateDirectories: false, attributes: nil)
			let dirUrl = NSURL(string: "file://" + mapScaleDir)!
			try? dirUrl.setResourceValue(true, forKey: URLResourceKey.isExcludedFromBackupKey)
			// copy color table and group info file
			let bundleColtblFile = bundleMapScaleDir + "/coltbl.bin"
			let colTblFile = mapScaleDir + "/coltbl.bin"
			do {
				try fileManager.copyItem(atPath: bundleColtblFile, toPath: colTblFile)
			} catch _ {
				try? fileManager.removeItem(atPath: colTblFile)
				try? fileManager.copyItem(atPath: bundleColtblFile, toPath: colTblFile)
			}
			// copy map tile group info file
			let bundleGprinfoFile = bundleMapScaleDir + "/grp.dat"
			let grpinfoFile = mapScaleDir + "/grp.dat"
			do {
				try fileManager.copyItem(atPath: bundleGprinfoFile, toPath: grpinfoFile)
			} catch _ {
				try? fileManager.removeItem(atPath: grpinfoFile)
				try? fileManager.copyItem(atPath: bundleGprinfoFile, toPath: grpinfoFile)
			}
			let grpinfoFileUrl = NSURL(string: "file://" + grpinfoFile)!
			try? grpinfoFileUrl.setResourceValue(true, forKey: URLResourceKey.isExcludedFromBackupKey)
		}
	}
	// directories all set
	let newfstat = "1"
	try? newfstat.write(to: URL(string: mapStatFile)!, atomically: false, encoding: String.Encoding(rawValue: String.Encoding.utf8.rawValue))
	try? NSURL(string: mapStatFile)?.setResourceValue(true, forKey: URLResourceKey.isExcludedFromBackupKey)
	return 0
}
