//
//  MapDownloaderObj.swift
//  downLoader
//
//  Created by Tomonao Yuzawa on 2017/06/12.
//  Copyright © 2017年 beshio. All rights reserved.
//

import UIKit
import Dispatch

// really helpful for multiple downloads. http://www.appcoda.com/background-transfer-service-ios7/
// this helps for background download. http://joyplot.com/documents/2016/09/30/swift-urlsession-progressbar/
// good info, MUST read. https://blog.newrelic.com/2016/01/13/ios9-background-execution/
// MUST read this for ATS. http://qiita.com/peromasamune/items/f5b72c4dbd33b5019611 and setup info.plist accordingly
// tutorial: https://www.raywenderlich.com/158106/urlsession-tutorial-getting-started
// good info: https://www.objc.io/issues/5-ios7/multitasking/
// good info: http://qiita.com/aKentaKoyama/items/96a979ab3a140e7b39ec
// MUST do w/ real device. https://stackoverflow.com/questions/32676352/urlsessiondidfinisheventsforbackgroundurlsession-not-calling-objective-c
// background ops:
// https://developer.xamarin.com/guides/ios/application_fundamentals/backgrounding/part_3_ios_backgrounding_techniques/ios_backgrounding_with_tasks/

// map downlaod info
//
class MapDownloadInfo {
	var urlPrefix: String!				// URL of files to be downloaded
	var urlSuffix: String!				// URL suffix, usually ".png"
	var downloadFiles: [String] = []	// file names
	var dstFiles: [String] = []			// target file name, xxx-yyy.png
	var dstDir: String!					// directory to put downloaded files
	var coltbl: UnsafeMutablePointer<UInt32>!
}

// downloaded file (tile) info
//
struct DownloadScaleInfo {
	var zsVal: UInt32 = 0
	var taskIDs: [Int64] = []	// url session task id
	// bit-0: file download access, bit-1: status access. (bit-0 is not used w/ curent impl)
	var completed: [Int] = []
}

// internal control data
//
private class MapDownloadInternalInfo {
	var useCellular = false
	var downloadScaleInfo: [DownloadScaleInfo] = []
	
	// find task id in downloadScaleInfo array
	//
	func findTaskId(taskId: Int, fileAccess: Bool) -> (zsVal: UInt32, xt: UInt32, yt: UInt32, dup: Bool)! {
		let taskId64 = Int64(taskId)
		for i in 0 ..< downloadScaleInfo.count {
			let count = downloadScaleInfo[i].taskIDs.count
			for j in 0 ..< count {
				if (taskId64 == downloadScaleInfo[i].taskIDs[j]) {
					// we found it
					var dup = false
					let completed = downloadScaleInfo[i].completed[j]
					if (fileAccess) {
						if (completed & 1 != 0) {
							dup = true
						} else {
							dup = false
							downloadScaleInfo[i].completed[j] |= 1
						}
					} else {
						if (completed & 2 != 0) {
							dup = true
						} else {
							dup = false
							downloadScaleInfo[i].completed[j] |= 2
						}
					}
					return (zsVal: downloadScaleInfo[i].zsVal, xt: 0, yt: 0, dup: dup)
				}
			}
		}
		return nil
	}

#if DEBUG
	deinit {
		print("MapDownloadInternalInfo: deinit")
	}
#endif
}

// handle background map download
//
class MapDownloaderObj: NSObject, URLSessionDownloadDelegate, URLSessionDelegate {
	static let sharedInstance = MapDownloaderObj()	// singleton object. http://hayaritai.hatenablog.jp/entry/2016/06/23/064940
	var relaunch = false			// true when reincarnation
	var session: URLSession!
	var mapDownloadInfo: [MapDownloadInfo]!
	var useCellular: Bool = false
	private var mapDownloadInternalInfo: MapDownloadInternalInfo!
	let bsem = DispatchSemaphore(value: 1)
	var dspgrp: DispatchGroup!
	var abort = false		// aborted by user
	var suspendXmit = false	// background task expired. need user to put the app to foreground. acrually, task runs after expiration,
							// but doing do will prevent system calling handleEventsForBackgroundURLSession
	var xmitDone = false	// all file requests sent
	var xsem: DispatchSemaphore!	// wake xmit task up after app gets foreground
	var backgroundTaskID: UIBackgroundTaskIdentifier!
	dynamic var remainedCount = 0	// remained file count. Key Value Observing. http://qiita.com/Kei-Kamikawa/items/9d6d661bff2d15ceac51
	dynamic var runOutOfTime = false	// no background task any more
	var totalCount = 0		// total file count
	var newDownload = false	// set true once user started download
	var colorTables: [(scIdx: Int, coltbl: UnsafeMutablePointer<UInt32>)] = []
	var csem = DispatchSemaphore(value: 1)
	var pngque: DispatchQueue!
	var pnggrp: DispatchGroup!
	
	// not sure w/ swift but need to revert to initial semaphore value w/ obj-c
	// http://lists.apple.com/archives/cocoa-dev/2014/Apr/msg00483.html
	//
	func setSemaphore(sem: DispatchSemaphore, count: Int) {
		while (sem.wait(timeout: DispatchTime.now()) == .success) {}
		for _ in 0 ..< count {sem.signal()}
	}
	
	// reset to initial state
	//
	func resetObj() {
		session = nil
		mapDownloadInfo = nil
		useCellular = false
		mapDownloadInternalInfo = nil
		dspgrp = nil
		if (xsem != nil) {
			setSemaphore(sem: xsem, count: 0)
			xsem = nil
		}
		backgroundTaskID = UIBackgroundTaskInvalid
		for i in 0 ..< colorTables.count {
			colorTables[i].coltbl.deallocate(capacity: 256)
		}
		colorTables.removeAll()
	}

	// init obj
	//
	private override init() {
		super.init()
		resetObj()
	}
	
	// relaunch
	//
	func reincarnation() {
		let flagExists = MapDownloaderObj.checkAndRemoveFlagFile(remove: false)
		if (!flagExists) {
			// no flag file. we have several choices
			if UserDefaults.standard.object(forKey: "createSessionWithoutFlag") != nil {
				let createSessionAnyway = UserDefaults.standard.bool(forKey: "createSessionWithoutFlag")
				if (!createSessionAnyway) {
					// ignore relaunch. in 20 sec or so, OS will kill me
					let appDelegate = UIApplication.shared.delegate as! AppDelegate
					appDelegate.backgroundSessionCompletionHandler = nil
					loggingMessage("* don't create session since no flag file")
					return
				}
			}
			// create session. this will result in memory waste or zombie
			loggingMessage("* create session but no flag file")
		} else {
			loggingMessage("* create session. flag file exists")
		}
		relaunch = true
		let sessionConfig = URLSessionConfiguration.background(withIdentifier: "jp.beshio.downLoader")
//		sessionConfig.allowsCellularAccess = useCellular
		sessionConfig.timeoutIntervalForResource = 3600.0
		session = URLSession(configuration: sessionConfig, delegate: self, delegateQueue: nil)
	}
	
	// check and remove flag file
	//
	class func checkAndRemoveFlagFile(remove: Bool) -> Bool {
		let dwldFlagFile = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true)[0] + "/download/downloadFlag.dat"
		let fileExists = FileManager().fileExists(atPath: dwldFlagFile)
		if (fileExists && remove) {
			try? FileManager().removeItem(atPath: dwldFlagFile)
			loggingMessage("* removing flag file")
		}
		return fileExists
	}
	
	// session finished
	//
	func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
#if DEBUG
		print("* urlSessionDidFinishEvents")
#endif
		loggingMessage("* urlSessionDidFinishEvents")
		bsem.wait()
		if (self.session == nil || (relaunch && newDownload) || (!relaunch && (!xmitDone || remainedCount != 0))) {
			// ignore very late relaunch after user's download or download at this sesion yet finished
#if DEBUG
			loggingMessage("* ignoring urlSessionDidFinishEvents")
#endif
			bsem.signal()
			return
		}
		resetObj()
		bsem.signal()
		session.invalidateAndCancel()
#if DEBUG
		loggingMessage("* canceling session")
#endif
		let appDelegate = UIApplication.shared.delegate as! AppDelegate
		appDelegate.asem.wait()
		if (appDelegate.viewDidAppearFlag || !relaunch) {
			// view has been already displayed. update UI
			appDelegate.doUpdateUI = true
		}
		appDelegate.urlSessionDidFinishEventsFlag = true
		appDelegate.asem.signal()
	}
	
	// kick background downloading
	//
	func startDownloadTask() {
		bsem.wait()
		newDownload = true
		xmitDone = false
		abort = false
		relaunch = false
		bsem.signal()
		runOutOfTime = false
		_ = MapDownloaderObj.checkAndRemoveFlagFile(remove: true)
		let downloadDir = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true)[0] + "/download/"
		// create internal control info data here before starting downloads
		mapDownloadInternalInfo = nil
		mapDownloadInternalInfo = MapDownloadInternalInfo()
		mapDownloadInternalInfo.useCellular = useCellular
		var totalFiles = 0
		for i in 0 ..< mapDownloadInfo.count {
			let dwldInfo = mapDownloadInfo[i]
			let zsVal32 = UInt32(mapDownloadInfo[i].dstDir)!
			var downloadScaleInfo = DownloadScaleInfo()
			downloadScaleInfo.zsVal = zsVal32
			let dwldDir = downloadDir + mapDownloadInfo[i].dstDir
			try? FileManager().createDirectory(atPath: dwldDir, withIntermediateDirectories: true, attributes: nil)
//			// we make copy of color table file to avoid complexity after relaunch (reincarnation)
//			let colorTblFile = dwldDir + "/coltbl.bin"
//			let fp = fopen(colorTblFile, "w")
//			if (fp != nil) {
//				fwrite(mapDownloadInfo[i].coltbl, MemoryLayout<UInt32>.size, 256, fp)
//				fclose(fp)
//			}
			for _ in 0 ..< dwldInfo.downloadFiles.count {
				downloadScaleInfo.completed.append(0)
				downloadScaleInfo.taskIDs.append(-1)
				totalFiles += 1
			}
			mapDownloadInternalInfo.downloadScaleInfo.append(downloadScaleInfo)
		}
		totalCount = totalFiles
		remainedCount = totalFiles
#if DEBUG
		print("total download files = \(totalFiles)")
#endif
		loggingMessage("* total download files = \(totalFiles)")
		startBackgroundTask()
		let sessionConfig = URLSessionConfiguration.background(withIdentifier: "jp.beshio.downLoader")
		sessionConfig.allowsCellularAccess = useCellular
		sessionConfig.timeoutIntervalForResource = 3600.0
		sessionConfig.timeoutIntervalForRequest = 1000.0  // not quite sure what this is for ???
		session = URLSession(configuration: sessionConfig, delegate: self, delegateQueue: nil)
		let dqueue = DispatchQueue(label: "", attributes: [])
		pngque = DispatchQueue(label: "", attributes: .concurrent)
		pnggrp = DispatchGroup()
		dspgrp = DispatchGroup()
		dqueue.async(group: dspgrp, execute: startDownloadTaskThread)
	}
	
	// stop downloading
	//
	func stopDownloadTask(removeFlagFile: Bool) {
#if DEBUG
		print("set abort")
#endif
		loggingMessage("* set abort")
		abort = true
		bsem.wait()
		if (session == nil || suspendXmit) {
			bsem.signal()
			return
		}
		bsem.signal()
		// see if xmit thread is waiting to become foreground
		dspgrp.wait()
#if DEBUG
		print("xmit canceled")
#endif
		loggingMessage("* xmit canceled")
		bsem.wait()
		if (session != nil) {
			session.invalidateAndCancel()
			if (removeFlagFile) {
				_ = MapDownloaderObj.checkAndRemoveFlagFile(remove: true)
			}
		}
		if (backgroundTaskID != UIBackgroundTaskInvalid) {
			let application = UIApplication.shared
			application.endBackgroundTask(backgroundTaskID)
			backgroundTaskID = UIBackgroundTaskInvalid
		}
		resetObj()
		bsem.signal()
#if DEBUG
		print("abort done")
#endif
		loggingMessage("* abort done")
	}

	// session canceled. note this func is not always called as expected. don't relay on it !
	//
	func urlSession(_ session: URLSession, didBecomeInvalidWithError error: Error?) {
#if DEBUG
		print("* session canceled")
#endif
		loggingMessage("* session canceled")
	}
	
	// kick background downloading
	//
	func startDownloadTaskThread() {
		abort = false
		suspendXmit = false
		xsem = DispatchSemaphore(value: 0)
		let application = UIApplication.shared
		// now, start download. Note we should start *ALL* of downloads here, or multiple session-completions would come.
		let count = mapDownloadInfo.count
#if DEBUG
		NSLog("start")
		loggingMessage("**** start downloading ****")
		var fc = 0
#endif
		for i in 0 ..< count {
			let dwldInfo = mapDownloadInfo[i]
			let filePrefix = dwldInfo.dstDir + "/"
			let count2 = dwldInfo.downloadFiles.count
			for j in 0 ..< count2 {
				if (abort) {
					return
				}
#if DEBUG && true
				print(String(format: "remaining time = %5g", application.backgroundTimeRemaining))
#endif
				loggingMessage(String(format: "remaining time = %5g", application.backgroundTimeRemaining))
				if (suspendXmit) {
					NotificationCenter.default.addObserver(self, selector: #selector(willEnterForeground(notification:)), name: NSNotification.Name(rawValue: "applicationWillEnterForeground"), object: nil)
					xsem.wait()
					startBackgroundTask()
					print("resuming xmit")
					loggingMessage("* resuming xmit")
				}
				var remoteFile = dwldInfo.urlPrefix + dwldInfo.downloadFiles[j]
				remoteFile += dwldInfo.urlSuffix
				let url = URL(string: remoteFile)!
				let downloadTask = session.downloadTask(with: url)
				downloadTask.taskDescription = filePrefix + dwldInfo.dstFiles[j]
				fc += 1
#if DEBUG
				print("req: \(fc)/\(totalCount) : \(downloadTask.taskIdentifier)")
#endif
				loggingMessage("req: \(fc)/\(totalCount) : \(downloadTask.taskIdentifier)")
				bsem.wait()  // not sure if array element mod requires lock in swift. seems ok w/o it, but take safe side.
				mapDownloadInternalInfo.downloadScaleInfo[i].taskIDs[j] = Int64(downloadTask.taskIdentifier)
				bsem.signal()
				downloadTask.resume()
			}
		}
		// create flag file for relaunch, which means we were in downloading now
		let downloadDir = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true)[0] + "/download/"
		try? FileManager().createDirectory(atPath: downloadDir, withIntermediateDirectories: false, attributes: nil)
		let downloadFlagFile = downloadDir + "downloadFlag.dat"
		let fdflg = open(downloadFlagFile, O_CREAT)
		if (fdflg != -1) {
			var useCellularFlag: Int32 = useCellular ? 1 : 0
			write(fdflg, &useCellularFlag, MemoryLayout<Int32>.size)
			close(fdflg)
		}
#if DEBUG
		loggingMessage("flag file created\n******************\nxmit done")
		print("******************")
		NSLog("xmit done")
#endif
		bsem.wait()
		xmitDone = true
		if (backgroundTaskID != UIBackgroundTaskInvalid) {
			application.endBackgroundTask(backgroundTaskID)
			backgroundTaskID = UIBackgroundTaskInvalid
		}
		bsem.signal()
	}
	
	// enter to foreground
	//
	func willEnterForeground(notification: NSNotification?) {
		NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "applicationWillEnterForeground"), object: notification)
		if (suspendXmit) {
#if DEBUG
			print("resuming suspended xmit")
#endif
			loggingMessage("* resuming suspended xmit")
			suspendXmit = false
			runOutOfTime = false
			xsem.signal()
		}
	}
	
	// file download finished
	//
	func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
#if DEBUG && true
		print("          didFinishDownloadingTo:", downloadTask.taskIdentifier)
#endif
		loggingMessage("didFinishDownloadingTo: \(downloadTask.taskIdentifier)")
		// see if file exists. Note file can be non-existent after relaunch.
		let ftmp = location.absoluteString
		let tmpFile = ftmp.substring(with: ftmp.characters.index(ftmp.startIndex, offsetBy: 7) ..< ftmp.characters.endIndex)  // 7=strlen("file://")
		let fileManager = FileManager()
		if (!fileManager.fileExists(atPath: tmpFile) || downloadTask.taskDescription == nil) {
			// no file or no destination info
#if DEBUG
			print("... no file ... : \(downloadTask.taskIdentifier)\n\(tmpFile)")
#endif
			loggingMessage("... no file ... : \(downloadTask.taskIdentifier)\n\(tmpFile)")
			return
		}
		if (abort) {
			return
		}
		// search internal download info table
		if (!relaunch) {
			bsem.wait()
			let tileInfo = mapDownloadInternalInfo.findTaskId(taskId: downloadTask.taskIdentifier, fileAccess: true)
			bsem.signal()
			if (tileInfo == nil) {
				// task ID not found, should be zombie from previous download
#if DEBUG
				print("... no task id ...")
#endif
				loggingMessage("... no task id ...")
				return
			}
		}
		// move file to destination
		let downloadDir = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true)[0] + "/download/"
		let fileName = downloadDir + downloadTask.taskDescription! + ".png"
		do {
			try fileManager.moveItem(at: location, to: URL(string: "file://" + fileName)!)
		} catch /*let error as NSError*/ {
			// this should be duplicated file. Since the process of prev file can be on going, I let system erase new one by doing nothing.
			return
		}
		// extract dir part from file name
		let pathComp = (downloadTask.taskDescription!.components(separatedBy: "/"))
		let tmpDir = NSTemporaryDirectory() + pathComp[0]
		try? FileManager().createDirectory(atPath: tmpDir, withIntermediateDirectories: true, attributes: nil)
		bsem.wait()
		if (self.session == nil) {
			bsem.signal()
			return
		}
		bsem.signal()
#if false
		// convert to size shrunk format (1bpp->1bpp, 2bpp->2bpp, 4bpp->4bpp, the other bpps->8bpp)
//		let gq = DispatchQueue.global(qos: .background)
//		gq.async {
//		pngque.async {
		pngque.async(group: pnggrp, execute: {() -> Void in
			let scIdx = Int(pathComp[0])!
			var found = false
			var idx = 0
			self.csem.wait()
			let count = self.colorTables.count
			for i in 0 ..< count {
				if (self.colorTables[i].scIdx == scIdx) {
					found = true
					idx = i
					break
				}
			}
			let dwldFileDir = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true)[0] + "/download/\(scIdx)"
			if (!found) {
				let colTblFile = dwldFileDir + "/coltbl.bin"
				let fp = fopen(colTblFile, "rb")
				if (fp == nil) {
					self.csem.signal()
					return
				}
				let coltbl = UnsafeMutablePointer<UInt32>.allocate(capacity: 256)
				fread(coltbl, MemoryLayout<UInt32>.size, 256, fp)
				fclose(fp)
				self.colorTables.append((scIdx: scIdx, coltbl: coltbl))
				idx = count
			}
			let coltbl = self.colorTables[idx].coltbl
			self.csem.signal()
			let result = ConvertPngFile(fileName, tmpDir, coltbl)
			let pngModFile = tmpDir + "/" + pathComp[1] + ".p\(result)"
			if (result == 0) {
				// file error
				try? FileManager().removeItem(atPath: pngModFile)
				return
			}
			// move converted file to cache dir and delete png file
			let dstFile = dwldFileDir + "/" + pathComp[1] + ".p\(result)"
			try? FileManager().removeItem(atPath: dstFile)
			do {
				try FileManager().moveItem(atPath: pngModFile, toPath: dstFile)
				try? FileManager().removeItem(atPath: fileName)
			} catch {
				try? FileManager().removeItem(atPath: pngModFile)
			}
		})
#endif
	}
	
#if DEBUG && false
	// download update for indiv file
	//
	func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
		let progress = Float(totalBytesWritten) / Float(totalBytesExpectedToWrite)
		print(String(format: "%.2f", progress * 100) + "%")
	}
#endif
	
	// single task completed, either fail or success
	//
	func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
#if DEBUG && true
		print("          didCompleteWithError: \(task.taskIdentifier)")
		if (error == nil) {
			loggingMessage("didCompleteWithError: \(task.taskIdentifier) : \(remainedCount-1)/\(totalCount)")
		} else {
			print("          \(String(describing: error!))")
			loggingMessage("didCompleteWithError: \(task.taskIdentifier) : \(remainedCount-1)/\(totalCount) : \(String(describing: error!))")
		}
#endif
		if (relaunch) {
			// we don't do anything since file count doesn't reflect the reality...
			return
		}
		bsem.wait()
		if (abort || self.session == nil) {
			bsem.signal()
			return
		}
		let tileInfo = mapDownloadInternalInfo.findTaskId(taskId: task.taskIdentifier, fileAccess: false)
		if (tileInfo == nil || (tileInfo?.dup)!) {
			// os sends duplicated info for some reason, and zombies from prev session are sometimes sent
			bsem.signal()
			return
		}
		remainedCount -= 1
		if (remainedCount != 0) {
			bsem.signal()
			return
		}
		bsem.signal()
		// all done
#if DEBUG
		print("***** all done *****")
		loggingMessage("***** all done *****")
#endif
		let state = UIApplication.shared.applicationState
#if DEBUG
		if (state == .background) {
			print("app is in background")
			loggingMessage("app is in background")
		} else if (state == .active) {
			print("app is active")
			loggingMessage("app is active")
		} else if (state == .inactive) {
			print("app is inactive")
			loggingMessage("app is inactive")
		}
#endif
		if (!relaunch) {
			// when we suspend to request due to timeout of background task, system calles urlSessionDidFinishEvents.
			// after that, even if we resume download, no urlSessionDidFinishEvents is called. don't know why...
			// So need to let user know here. if relaunch, handleEventsForBackgroundURLSession/urlSessionDidFinishEvents will anyway come.
			session.invalidateAndCancel()
			resetObj()
			let appDelegate = UIApplication.shared.delegate as! AppDelegate
			appDelegate.asem.wait()
			appDelegate.doUpdateUI = true
			appDelegate.asem.signal()
		}
#if DEBUG
		NSLog("end")
#endif
	}
	
	// start background task
	//
	func startBackgroundTask() {
		let application = UIApplication.shared
		backgroundTaskID = application.beginBackgroundTask() {
			// actually, even after remaining time gets zero, we can still request download even though we call endBackgroundTask below.
			// but to be a good citizen, I suspend the download request.
			print("* endBackroundTask by system")
			application.endBackgroundTask(self.backgroundTaskID)
			self.backgroundTaskID = UIBackgroundTaskInvalid
			self.suspendXmit = true
			// ask user to make the app to foreground
			self.runOutOfTime = true
		}
	}
	
#if DEBUG
	// emulate background task expiration
	//
	func emulateBkgTaskExpiration() {
		if (backgroundTaskID != UIBackgroundTaskInvalid) {
			print("* endBackroundTask by emulation")
			let application = UIApplication.shared
			application.endBackgroundTask(backgroundTaskID)
			backgroundTaskID = UIBackgroundTaskInvalid
			suspendXmit = true
			// ask user to make the app to foreground
			runOutOfTime = true
		}
	}
#endif
	
#if DEBUG
	// this will never get called w/ current implementation
	deinit {
		print("MapDownloaderObj: deinit")
	}
#endif
}
