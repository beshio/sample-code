//
//  ShowLogFileViewController.swift
//  downLoader
//
//  Created by Tomonao Yuzawa on 2017/08/22.
//  Copyright © 2017年 beshio. All rights reserved.
//

import UIKit

// https://stackoverflow.com/questions/32021712/how-to-split-a-string-by-new-lines-in-swift
//
//extension String {
//	var lines: [String] {
//		var result: [String] = []
//		enumerateLines { line, _ in result.append(line) }
//		return result
//	}
//}

extension String {
	init?(utf8ptr: UnsafePointer<Int8>) {
		self.init(cString: UnsafeRawPointer(utf8ptr).assumingMemoryBound(to: CChar.self), encoding: .utf8)
	}
}

class ShowLogFileViewController: UIViewController, PopoverControllerProtocol {
	@IBOutlet weak var textView: UITextView!
	var rightButtons: [UIBarButtonItem]! = []	// right buttons of navigation bar
	var downloadReq = true
	var remainingTime = true
	var didFinishDwldTo = true
	var didComplete = true
	var downloadReq0 = true
	var remainingTime0 = true
	var didFinishDwldTo0 = true
	var didComplete0 = true
	var filterMenu: PopoverMenuController!
	var contents: String!
	
	// view will appear. setup navigation bar
	//
	override func viewWillAppear(_ animated: Bool) {
		navigationController!.setNavigationBarHidden(false, animated: animated)
		super.viewWillAppear(animated)
	}

	// set filter
	//
	func flipDwldReq(_ action: PopMenuAction?) -> Bool {
		downloadReq = !downloadReq
		UserDefaults.standard.set(downloadReq, forKey: "downloadReq")
		let cell = filterMenu.getCell(0)
		let acc: UITableViewCellAccessoryType = downloadReq ? .checkmark : .none
		cell.accessoryType = acc
		return false
	}
	
	func flipRemainingTime(_ action: PopMenuAction?) -> Bool {
		remainingTime = !remainingTime
		UserDefaults.standard.set(remainingTime, forKey: "remainingTime")
		let cell = filterMenu.getCell(1)
		let acc: UITableViewCellAccessoryType = remainingTime ? .checkmark : .none
		cell.accessoryType = acc
		return false
	}
	
	func flipFinishDwld(_ action: PopMenuAction?) -> Bool {
		didFinishDwldTo = !didFinishDwldTo
		UserDefaults.standard.set(didFinishDwldTo, forKey: "didFinishDwldTo")
		let cell = filterMenu.getCell(2)
		let acc: UITableViewCellAccessoryType = didFinishDwldTo ? .checkmark : .none
		cell.accessoryType = acc
		return false
	}
	
	func flipComplete(_ action: PopMenuAction?) -> Bool {
		didComplete = !didComplete
		UserDefaults.standard.set(didComplete, forKey: "didComplete")
		let cell = filterMenu.getCell(3)
		let acc: UITableViewCellAccessoryType = didComplete ? .checkmark : .none
		cell.accessoryType = acc
		return false
	}
	
	// filter menu
	//
	func filterTapped(_ sender: AnyObject) {
		downloadReq0 = downloadReq
		remainingTime0 = remainingTime
		didFinishDwldTo0 = didFinishDwldTo
		didComplete0 = didComplete
		filterMenu = PopoverMenuController()
		filterMenu.delegate = self
		filterMenu.exitWhenSelected = false
		filterMenu.sourceBtnItem = rightButtons[0]
		filterMenu.arrowDirection = UIPopoverArrowDirection.up
		var acc: UITableViewCellAccessoryType = downloadReq ? .checkmark : .none
		filterMenu.addAction(PopMenuAction(textLabel: "download request", accessoryType: acc, handler: flipDwldReq))
		acc = remainingTime ? .checkmark : .none
		filterMenu.addAction(PopMenuAction(textLabel: "remaining time", accessoryType: acc, handler: flipRemainingTime))
		acc = didFinishDwldTo ? .checkmark : .none
		filterMenu.addAction(PopMenuAction(textLabel: "didFinishDownloadingTo", accessoryType: acc, handler: flipFinishDwld))
		acc = didComplete ? .checkmark : .none
		filterMenu.addAction(PopMenuAction(textLabel: "didCompleteWithError", accessoryType: acc, handler: flipComplete))
		present(filterMenu, animated: true, completion: nil)
		rightButtons[2].isEnabled = false
		rightButtons[4].isEnabled = false
	}
	
	// popober done
	//
	func popoverControllerDone(_ noaction: Bool, tot: Bool) {
		if (!noaction) {
			return
		}
		rightButtons[2].isEnabled = true
		rightButtons[4].isEnabled = true
		filterMenu.dismissPopOverMenu(true)
		filterMenu = nil
		let filterChanged = (downloadReq0 != downloadReq) || (remainingTime0 != remainingTime) || (didFinishDwldTo0 != didFinishDwldTo) || (didComplete0 != didComplete)
		if (!filterChanged) {
			return
		}
		// redraw log w/ new filter
		setFilteredString()
	}
	
	// set filter to string
	//
	func setFilteredString() {
		if (downloadReq && remainingTime && didFinishDwldTo && didComplete) {
			textView.text = contents
			return
		}
		var partOfContents = ""
		let count = lineStrs.count
		for i in 0 ..< count {
			if (lineAttrs[i] == 0 || (lineAttrs[i] == 1 && downloadReq) || (lineAttrs[i] == 2 && remainingTime) || (lineAttrs[i] == 3 && didFinishDwldTo) || (lineAttrs[i] == 4 && didComplete)) {
				partOfContents += lineStrs[i]
			}
		}
//		contents.enumerateLines {line, _ in
//			partOfContents += line
//			print(line)
//		}
		textView.text = partOfContents
	}
	
	// jump to top/last
	//
	func jumpToTop(_ sender: AnyObject) {
		let txtlen = textView.text.lengthOfBytes(using: .utf8)
		if (txtlen == 0) {
			return
		}
		let top = NSMakeRange(1, 1)
		textView.scrollRangeToVisible(top)
	}
	
	func jumpToLast(_ sender: AnyObject) {
		let txtlen = textView.text.lengthOfBytes(using: .utf8)
		if (txtlen == 0) {
			return
		}
		let bottom = NSMakeRange(txtlen-1, 1)
		textView.scrollRangeToVisible(bottom)
	}
	
	// setup nav bar
	//
	func setupNavBar() {
		navigationController?.navigationBar.isTranslucent = false
		let spaceArea = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
		rightButtons.append(UIBarButtonItem(title: "Filter", style: UIBarButtonItemStyle.plain, target: self, action: #selector(filterTapped(_:))))
		rightButtons.append(spaceArea)
		rightButtons.append(UIBarButtonItem(title: "Last", style: UIBarButtonItemStyle.plain, target: self, action: #selector(jumpToLast(_:))))
		rightButtons.append(spaceArea)
		rightButtons.append(UIBarButtonItem(title: "Top", style: UIBarButtonItemStyle.plain, target: self, action: #selector(jumpToTop(_:))))
		rightButtons.append(spaceArea)
		navigationItem.rightBarButtonItems = rightButtons
	}
	
	var lineStrs: [String] = []
	var lineAttrs: [Int] = []

	// view loaded
	//
	override func viewDidLoad() {
		if UserDefaults.standard.object(forKey: "downloadReq") != nil {
			downloadReq = UserDefaults.standard.bool(forKey: "downloadReq")
		}
		if UserDefaults.standard.object(forKey: "remainingTime") != nil {
			remainingTime = UserDefaults.standard.bool(forKey: "remainingTime")
		}
		if UserDefaults.standard.object(forKey: "didFinishDwldTo") != nil {
			didFinishDwldTo = UserDefaults.standard.bool(forKey: "didFinishDwldTo")
		}
		if UserDefaults.standard.object(forKey: "didComplete") != nil {
			didComplete = UserDefaults.standard.bool(forKey: "didComplete")
		}
		let logfile = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] + "/logging.txt"
		contents = try! String(contentsOfFile: logfile, encoding: String.Encoding.utf8)
		// analyze file data
		let fp = fopen(logfile, "r")
		var st = stat()
		fstat(fileno(fp), &st)
		let fileLen = Int(st.st_size)
		let fileBuf = UnsafeMutablePointer<Int8>.allocate(capacity: fileLen+1)
		fileBuf[fileLen] = 0
		fread(fileBuf, fileLen, 1, fp)
		fclose(fp)
		var fbufp = fileBuf
		while (fbufp[0] != 0) {
			let lf = strchr(fbufp, 0x0a)
			lf?[0] = 0
			let line = String(utf8ptr: fbufp)! + "\n"
			//print(line)
			lineStrs.append(line)
			if (strstr(line, "req:") != nil) {
				lineAttrs.append(1)
			} else if (strstr(line, "remaining time") != nil) {
				lineAttrs.append(2)
			} else if (strstr(line, "didFinishDownloadingTo") != nil) {
				lineAttrs.append(3)
			} else if (strstr(line, "didCompleteWithError") != nil) {
				lineAttrs.append(4)
			} else {
				lineAttrs.append(0)
			}
			fbufp = lf! + 1
		}
		fileBuf.deallocate(capacity: fileLen+1)
		setupNavBar()
		setFilteredString()
	}
	
#if DEBUG
	deinit {
		print("ShowLogFileViewController: deinit")
	}
#endif
}
