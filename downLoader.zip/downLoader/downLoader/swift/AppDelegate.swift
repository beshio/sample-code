//
//  AppDelegate.swift
//  downLoader
//
//  Created by Tomonao Yuzawa on 2014/12/26.
//  Copyright (c) 2014年 beshio. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
	var backgroundSessionCompletionHandler: (() -> Void)?
	var localNotificationEnabled = false
	var window: UIWindow?
	var navigationController: UINavigationController?
	var mapDownloaderObj: MapDownloaderObj! = nil
	// next are place holder here
	let asem = DispatchSemaphore(value: 1)
	var viewDidAppearFlag = false
	var urlSessionDidFinishEventsFlag = false
	dynamic var doUpdateUI = false
	var removeFlagFileAtExit = true
	
	func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
#if DEBUG
		let logfile = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] + "/logging.txt"
		initLogging(logfile)
		loggingMessage("***************")
		loggingMessage("***************")
		loggingMessage("***************")
		loggingMessage("* didFinishLaunchingWithOptions")
		print("* didFinishLaunchingWithOptions")
#endif
#if true
		// see if we are in initial phase
		let mapStat = setupMapFolders()
		if (mapStat <= 1) {
			// we need to download low scale maps initially
			let storyboard = UIStoryboard(name: "Downloader", bundle: Bundle.main)
			let mainViewController = storyboard.instantiateInitialViewController()! as! DownloadViewController
			mainViewController.initState = mapStat
			navigationController = UINavigationController(rootViewController: mainViewController)
		} else {
		}
#elseif false
#endif
		navigationController!.isNavigationBarHidden = true
		navigationController!.isToolbarHidden = true
		window = UIWindow(frame: UIScreen.main.bounds)
		window!.rootViewController = navigationController
		window!.makeKeyAndVisible()
		return true
    }
	
	// receive local notification permission status
	//
	func application(_ application: UIApplication, didRegister notificationSettings: UIUserNotificationSettings) {
		let allowedType = notificationSettings.types
		if (allowedType == .alert) {
			localNotificationEnabled = true
		} else {
			localNotificationEnabled = false
		}
	}

	// entered to background
	// http://mzgkworks.hateblo.jp/entry/nsnotificationcenter-viewcontroller
	func applicationDidEnterBackground(_ application: UIApplication) {
		NotificationCenter.default.post(name: NSNotification.Name(rawValue: "applicationDidEnterBackground"), object: nil)
#if DEBUG
		print("* applicationDidEnterBackground")
		loggingMessage("* applicationDidEnterBackground")
#endif
	}
	
	// enter to foreground
	//
	func applicationWillEnterForeground(_ application: UIApplication) {
#if DEBUG
		print("* applicationWillEnterForeground")
		loggingMessage("* applicationWillEnterForeground")
#endif
		removeFiledownloadNotification()
		NotificationCenter.default.post(name: NSNotification.Name(rawValue: "applicationWillEnterForeground"), object: nil)
	}
	
	// application is about to terminate
	//
	func applicationWillTerminate(_ application: UIApplication) {
#if DEBUG
		print("* applicationWillTerminate")
		loggingMessage("* applicationWillTerminate")
#endif
		NotificationCenter.default.post(name: NSNotification.Name(rawValue: "applicationWillTerminate"), object: nil)
		if (mapDownloaderObj != nil) {
			if (mapDownloaderObj.session != nil) {
				// even though user canceled the session, we may still receive handleEventsForBackgroundURLSession
				// it seems some of the files are already regitered to system for background downloading
				mapDownloaderObj.stopDownloadTask(removeFlagFile: removeFlagFileAtExit)
			}
		}
#if DEBUG
		print("* see you!")
		loggingMessage("* see you!")
#endif
	}

	func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

	// URL session completed. MUST go w/ real device since simulator doesn't call this delegate
	// https://stackoverflow.com/questions/32676352/urlsessiondidfinisheventsforbackgroundurlsession-not-calling-objective-c
	//
	func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String, completionHandler: @escaping () -> Void) {
#if DEBUG
		let logfile = NSSearchPathForDirectoriesInDomains(.libraryDirectory, .userDomainMask, true)[0] + "/logging.txt"
		initLogging(logfile)
		loggingMessage("* handleEventsForBackgroundURLSession")
		print("* handleEventsForBackgroundURLSession")
#endif
		backgroundSessionCompletionHandler = completionHandler
		if (mapDownloaderObj == nil) {
			mapDownloaderObj = MapDownloaderObj.sharedInstance
			mapDownloaderObj.reincarnation()
		}
	}
}
