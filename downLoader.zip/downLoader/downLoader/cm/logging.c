//
//  logging.c
//  downLoader
//
//  Created by Tomonao Yuzawa on 2017/07/09.
//  Copyright © 2017年 beshio. All rights reserved.
//

#include <stdio.h>
#include <time.h>
#include <limits.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/time.h>
#include "logging.h"

static pthread_mutex_t g_mtx;
static FILE *g_fp;

void initLogging(const char *logfile) {
	if (g_fp)  return;
	g_fp = fopen(logfile, "a");
	if (g_fp) {
		pthread_mutex_init(&g_mtx, NULL);
	}
}

void loggingMessage(const char *msg) {
	if (!g_fp)  return;
	pthread_mutex_lock(&g_mtx);
	struct timeval tval;
	gettimeofday(&tval, NULL);
	struct tm *t_st = localtime(&tval.tv_sec);
	fprintf(g_fp, "%02d:%02d:%02d.%03d %s\n", t_st->tm_hour, t_st->tm_min, t_st->tm_sec, tval.tv_usec/1000, msg);
	fflush(g_fp);
	pthread_mutex_unlock(&g_mtx);
}

void clearLogging() {
	if (!g_fp)  return;
	pthread_mutex_lock(&g_mtx);
	ftruncate(fileno(g_fp), 0);
	fseek(g_fp, 0, SEEK_SET);
	pthread_mutex_unlock(&g_mtx);
}

long youAreDone() {
	// try to die
	long addr = 1;
	long lval = *((long *)addr);
	return lval;
}
