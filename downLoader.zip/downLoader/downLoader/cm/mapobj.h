#pragma once

#ifdef __cplusplus
extern "C" {
#endif
	typedef void MAPCTRL;
	typedef void MAPGRP;
	typedef void MAPOBJ;
	
	// map object
	MAPOBJ *CreateMapObj(MAPGRP *mg, int scidx);
	void DestroyMapObj(const MAPOBJ *mo);
	
	// map group object
	MAPGRP *CreateMapGrp(MAPCTRL *mc, const char *grpname);
	void DestroyMapGrp(const MAPGRP *mg);
	
	// map control object. don't create more than one.
	MAPCTRL *CreateMapCtrl(const char *rootdir);
	void DestroyMapCtrl(MAPCTRL *mc);
	
	void GetMaxTileNum(const MAPGRP *mg, int **nx, int **ny);
	
	// map tile data request and get them
	int RequestMapTiles(const MAPOBJ *mobj, int colidx, int ntiles, const unsigned *tlist);
	int GetNextMapTile(const MAPOBJ *mobj, unsigned **tdata, unsigned *tilenum, int *tidx);

	int GetMapScales(const MAPGRP *mg, double **sc);
	void LatLon2XY(const MAPOBJ *mobj, double lat, double lon, double *x, double *y);
	void XY2LatLon(const MAPOBJ *mobj, double x, double y, double *lat, double *lon);
	void LatLon2XYwithScaleIndex(const MAPOBJ *mobj, int scaleIndex, double lat, double lon, double *x, double *y);
	void XY2LatLonWithScaleIndex(const MAPOBJ *mobj, int scaleIndex, double x, double y, double *lat, double *lon);
	int GetExisting2ndMeshList(const MAPOBJ *mobj, int *pnx, int *pny, char **m2list);
	void GetNativeDatum(const MAPOBJ *mobj, double lat, double lon, double *vlat, double *vlon);
	int GetMapOrigins(const MAPGRP *mg, int **lat, int **lon);
	void moMemShutdown(int adj);
	void moMemCheck();
	int ConvertTileNumber(const MAPGRP *mg, int scidx0, unsigned tnum0, int scidx1, int *xtnum1, int *ytnum1);
	int ConvertTileNumbers(const MAPGRP *mg, int nt, int scidx0, const unsigned *tnums0, const unsigned *snums0, int scidx1, unsigned *tnums1);
	void GetTileInfoList(const MAPGRP *mg, int nt, int scIdx, const unsigned *tnums, unsigned *tileInfo);
	void GetDownloadInfo(const MAPGRP *mg, int *downloadScale, int *downloadDispScale, double *maxZoomAtDispMap);
	void GetMapScaleInfo(const MAPGRP *mg, double *sysScale, double *minZoomScaleAtMax, double *maxZoomScaleAtMin);
	void RequestMapTileFileDataInfo(const MAPOBJ *mobj, int ntiles, const unsigned *tlist, unsigned *tlen);
	int RequestEntireMapTilePossessionInfo(const MAPOBJ *mobj, unsigned **ptlist);
	int RequestEntireValidMapTileInfo(const MAPOBJ *mobj, unsigned **ptlist, int sync);
	int GetPrivateProfileStr(const char *sect, const char *key, const char *defstr, char *srtn, int nSize, const char *inifile);
	MAPOBJ *CreateMapObjWithNoMapdata(const MAPGRP *mg, int scidx);
	unsigned *RequestColorTable(const MAPOBJ *mobj);
#ifdef __cplusplus
}
#endif
