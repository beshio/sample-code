//
//  logging.h
//  downLoader
//
//  Created by Tomonao Yuzawa on 2017/07/09.
//  Copyright © 2017年 beshio. All rights reserved.
//

#ifndef logging_h
#define logging_h

void initLogging(const char *logfile);
void loggingMessage(const char *msg);
void clearLogging();
long youAreDone();

#endif /* logging_h */
