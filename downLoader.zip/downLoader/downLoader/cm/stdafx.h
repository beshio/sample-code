#ifndef ThreedHiker_stdafx_h
#define ThreedHiker_stdafx_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>

#ifndef MAX_PATH
#define MAX_PATH PATH_MAX
#endif

#if 0
#define TRACE(...) fprintf(stdout, __VA_ARGS__)
#else
#define TRACE(...) fprintf(stderr, __VA_ARGS__)
#endif

#define ASSERT

//#define PERFMEASURE 1
#define USEGCD true
#endif
