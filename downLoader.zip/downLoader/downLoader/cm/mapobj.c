#include "stdafx.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <errno.h>
#include "zlib.h"
#include "Proj.h"

#define moMemInit()
#define moMemShutdown(a)
#define moMalloc(__l__) malloc(__l__)
#define moCalloc(__l__, __w__) calloc(__l__, __w__)
#define moFree(__v__) free(__v__)

#define TILE_W 256
#define TILE_H 256

#if defined(CYGWIN)||defined(__APPLE__)
#define USEPOSIX 1
#elif defined(_WIN32)
#define USEPOSIX 0
#else
#error "don't know platform..."
#endif

#if USEPOSIX
#define THREAD_STK_SIZ 65536
#define THREADCREATE(_func,_arg) {\
pthread_attr_t _at;\
pthread_attr_init(&_at);\
pthread_attr_setdetachstate(&_at, PTHREAD_CREATE_DETACHED);\
pthread_attr_setstacksize(&_at, THREAD_STK_SIZ);\
pthread_t _th;\
pthread_create(&_th, &_at, _func, _arg);\
}
#define THREADTYP void *
#define THREADARG void *
#define MUTEXCREATE(_mtx) pthread_mutex_init(&_mtx, NULL)
#define MUTEXLOCK(_mtx) pthread_mutex_lock(&_mtx)
#define MUTEXUNLOCK(_mtx) pthread_mutex_unlock(&_mtx)
#define MUTEXDESTROY(_mtx) pthread_mutex_destroy(&_mtx)
#define CONDCREATE(_cnd) pthread_cond_init(&_cnd,NULL)
#define CONDWAIT(_cnd,_mtx) pthread_cond_wait(&_cnd, &_mtx)
#define CONDSIG(_cnd) pthread_cond_signal(&_cnd)
#define CONDDESTROY(_cnd) pthread_cond_destroy(&_cnd)
#define SLEEP(_ms) usleep(_ms*1000)
#define STATFUNC stat
#define STATSTRUC stat
#define FSTATFUNC fstat
#define FILENO fileno
#define FTRUNCATE ftruncate
#define FSEEK fseek

#else	// USEPOSIX
#endif	// USEPOSIX

#ifdef PERFMEASURE
static long clkaccum0;
static int ntileaccum0;
static long clkaccum1;
static int ntileaccum1;
#endif

typedef struct {
    int numToc;				// number of toc records
    int numIdx;				// number of index records (=number of tiles)
    int idxSpan;			// span of block of index records for toc
    int idxOffset;			// file offset of index records
    int datOffset;			// file offset of data offset table
} IDXHEADER;

typedef struct {
    unsigned tileNum;		// top index record tile number
    int idxOffset;			// file offset of tile index record
} TOCREC;

typedef struct {
    long long datOffset;	// file offset of tile data in map data file
    unsigned tileNum;		// tile number, Y's tile number is at upper 16bit, and X's tilenumber at lower 16bit
    unsigned short tileLen;	// length of tile. tile in file is compressed. uncompressed size is 256x256=64k
    short padding;			// unused. for x8 byte boundary
} TILEIDX;

typedef struct {
    unsigned short tileLen;	// length of tile. tile in file is compressed. uncompressed size is 256x256=64k
    unsigned tileNum;	// tile number, Y's tile number is at upper 16bit, and X's tilenumber at lower 16bit
} DATHEADER;
#define DATHEADERLEN (sizeof(unsigned)+sizeof(short))  // USE this for short+unsigned alignment is hated !!

typedef struct {
    unsigned short tileLen;
    unsigned short tileNumX;
    unsigned short tileNumY;
} DATHEADER2;

#define DATFILE "mapdata.dat"
#define IDXFILE "mapidx.dat"
#define COLTBLFILE "coltbl.bin"
#define GRPFILE "grp.dat"

typedef struct {
    long long datOffset;	// file offset of tile data to be deleted
    int tileLen;			// length of tile to be deleted
    int idx;				// index of tile index
} HOLE;

typedef struct {
    long long datOffset;	// file offset of region
    long long regionLen;	// length of region
    long long regionUsed;	// length of re-used region
} HOLEREGION;

typedef struct {
	unsigned groupNum;	// = ((yGrpNum<<16)|xGrpNum)
	unsigned fileOffset;	// == fileOffset or 0xffffffff when fully populated group
} GRPINFO;

#define GRPSIZE 32		// must be multiple of 8

typedef struct {
	FILE *fp;
	unsigned numGroups;
	GRPINFO *grpInfo;
#define NUMGRPCACHE 4
	unsigned groupNum[NUMGRPCACHE];
	int groupIdx[NUMGRPCACHE];
	unsigned fullFlag[NUMGRPCACHE];
	unsigned char groupInfo[NUMGRPCACHE][GRPSIZE][GRPSIZE/8];
} TGRPINFO;

typedef struct {
    FILE *fpIdx;		// file pointer of index file
    FILE *fpDat;		// file pointer of data file
	TGRPINFO *tgi;		// tile group info
    void *mgrp;			// pointer to parent MAPGRP
    int m_idx;			// index in MAPINFO array
    int numToc;			// number of toc records
    int idxSpan;		// span of block of index records for toc
    int idxOffset;		// file offset of index records
    int numTile;		// number of tile records (= number of index records)
    int numCache;		// number of index record cache entries
#define NUM_TOCCACHE 64	// number of cache
    int cacheInIdx;		// cache input index
    TILEIDX *tcache[NUM_TOCCACHE];	// tile index cache pointer
    unsigned short cacheTocNum[NUM_TOCCACHE];	// toc record number for cache
    unsigned short numIdxRec[NUM_TOCCACHE];	// number of valid Index records in cache
    TOCREC toc[1];		// TOC rec. place holder
} MAPDATCTRL;

typedef MAPDATCTRL MAPOBJ;

typedef struct {
#if USEPOSIX
    pthread_mutex_t m_mtxnew;	// mutex to start new task
    pthread_cond_t m_cndnew;	// condition var to start new task
    pthread_mutex_t m_mtxrdy[2];	// mutex to notify file data ready. indexed by m_notifyIdx of FACCTHREADCTRL
    pthread_cond_t m_cndrdy[2];	// condition var to notify data ready
	pthread_mutex_t m_mtxfile;		// access control to file. may not be used for all threads
#else
#endif
} THREADCTRL;

typedef struct {
    THREADCTRL m_tct;
    MAPDATCTRL *m_md;	// map file control data
    volatile int m_nreq;		// number of requested tile data. if -1, then worker thread exits
    unsigned *m_tnum;	// tile numebr list. set by calling thread
    int *m_ctlen;	// length of compressed tile size, set by worker thread. if 0, then no such tile or error in file. set by worker thread
    char **m_ctdat;	// compressed tile data, set by worker thread. m_ctdat itself must be valid by caller.
    volatile int *m_numrdy;	// number of ready tile data newly read from file. access with lock.
	int m_notifyIdx;			// index of ready mutex/condition
} FACCTHREADCTRL;

typedef struct {
    THREADCTRL m_tct;
    volatile int m_cmd;			// command, 1 to process tile data. -1 to quit. if -1, then worker thread set -2 when ready to end
    MAPOBJ *m_mobj;		// pointer to map object
    int m_colidx;		// color table index or -1. if -1, prefetch request of file data
    int m_ntiles;		// number of requested tiles in m_tlist array
    unsigned *m_tlist;	// array of tile numbers
    unsigned **m_tiledat;	// tile data return. area w/ size of 256x256x4 is allocated internally. must be freed by caller
    volatile int m_nready;		// number of ready data in m_rdyidx array
    int *m_rdyidx;		// array to show which tile is ready
    volatile int m_numgotten;	// number of tiles that the caller has gotten
} TGENTHREADCTRL;

typedef struct {
    double m_scale;		// scale. eg. 25000.0, 70000.0, ...
    int m_ocean;		// color table index of ocean, which is used when no data
    MAPDATCTRL *m_mapdat;	// map data control array
    int m_orglat;		// latitude origin of map in mS
    int m_orglon;		// longitude origin of map in mS
    int m_prjlat;		// projection origin in mS
    int m_prjlon;		// projection origin in mS
    int m_proj;			// projection scheme
#define PRJ_MERC 0		// Mercator
#define PRJ_TMERC 1		// Transverse Mercator w/ ellipse
    double m_xorg;		// precomputed x coordinate of map origin
    double m_yorg;		// precomputed y coordinate of map origin
    double m_xyscale;	// precomputed scale factor for x,y coordinate
    int m_xmaxtile;		// max x tile number, inclusive
    int m_ymaxtile;		// max y tile number, inclusive
	PROJPARM m_pp;		// projection parameter
	unsigned m_coltbl[256];	// color table
} MAPINFO;

typedef struct {
    double m_zoom;		// zoom in %, determined when maps are organized
    int m_datum;		// WGS84 or TOKYO
#define DATUM_WGS84 0
#define DATUM_TOKYO 1
    int m_nscales;		// number of scales
	double m_systemScale;	// scale applied to all maps in the group
	double m_minZoomAtMaxMap;	// scale applied to max scale map to limit to shurink
	double m_maxZoomAtMinMap;	// scale applied to min scale map to limit to enlarge
	int m_downloadScale;	// download map w/ this unit. when -1, no download support w/ the map
	int m_downloadDispScale;	// map display scale at map download. All of the maps incl this scale should be resident
	double m_downloadMaxZoomAtDispMap;	// scale applied to min scale display map to limit to enlarge
    MAPINFO *m_mi;		// map info
    int m_bpp;			// bit per pixel, 1, 2, 4 or 8
    char *m_mapdir;		// map file root directory
    void *m_mapctrl;	// pointer to parent MAPCTRL
	TGRPINFO **m_tgi;	// prefetch of TGRPINFO. we hold here in case TGRPINFO requested w/o MAPINFO
} MAPGRP;

#define NUMTILECASH 128
typedef struct {
    int m_numTileCache;	// number of elements in cache
    int m_cachInIdx;	// next index to put cached data
    unsigned m_tileNum[NUMTILECASH];	// tile number array
    unsigned char m_scaleCode[NUMTILECASH];	// map scale code array
    unsigned char m_grpIdx[NUMTILECASH];	// map group index
    unsigned short m_tileLen[NUMTILECASH];	// length of comprssed data. if zero, then the tile is ocean.
    char *m_ctile[NUMTILECASH];		// compressed tile data
} TILECACHE;

#define NUMDECOMPCASH 64
typedef struct {
    int m_numDecompCache;   // number of decompressed elements in cache
    int m_cachInIdx;        // next index to put cache data
    unsigned m_tileNum[NUMDECOMPCASH];	// tile number array
    unsigned char m_scaleCode[NUMDECOMPCASH];	// map scale code array
    unsigned char m_grpIdx[NUMDECOMPCASH];	// map group index
    char *m_dtile[NUMTILECASH];		// decompressed tile data
} DECOMPCACHE;

typedef struct {
    char *m_rootdir;	// map data root directory
    TGENTHREADCTRL m_tgen;	// tile data gen thread control data
    FACCTHREADCTRL m_facc;	// file access thread control data
    TILECACHE m_cache;	// tile cache <== I put this struc here since this is statically created (no malloc)
    DECOMPCACHE m_dcache;   // decompressed tile cache
    int m_nmapgrp;		// number of map groups
    MAPGRP **m_mapgrp;	// map group
} MAPCTRL;

static void (*const g_prjfunc[])(double lat, double lon, double *xc, double *yc, PROJPARM *pp) = {
	Rad2Merc,	// PRJ_MERC
	Rad2TMerc	// PRJ_TMERC
};

#ifdef __cplusplus
extern "C" {
#endif
	MAPOBJ *CreateMapObj(MAPGRP *mg, int scidx);
	void DestroyMapObj(const MAPOBJ *mo);
	MAPGRP *CreateMapGrp(MAPCTRL *mc, const char *grpname);
	void DestroyMapGrp(const MAPGRP *mg);
	MAPCTRL *CreateMapCtrl(const char *rootdir);
	void DestroyMapCtrl(MAPCTRL *mc);
	int RequestMapTiles(const MAPOBJ *mobj, int colidx, int ntiles, const unsigned *tlist);
	int GetNextMapTile(const MAPOBJ *mobj, unsigned **tdata, unsigned *tilenum, int *tidx);
	
	int GetMapScales(const MAPGRP *mg, double **sc);
	void LatLon2XY(const MAPOBJ *mobj, double lat, double lon, double *x, double *y);
	void XY2LatLon(const MAPOBJ *mobj, double x, double y, double *lat, double *lon);
	
	int GetExisting2ndMeshList(const MAPOBJ *mobj, int *pnx, int *pny, char **m2list);
	void GetMaxTileNum(const MAPGRP *mg, int **nx, int **ny);
	void GetNativeDatum(const MAPOBJ *mobj, double lat, double lon, double *vlat, double *vlon);
	void LatLon2XYwithMapInfo(const MAPINFO *mi, double lat, double lon, double *x, double *y);
#ifdef __cplusplus
}
#endif

static int _cmpyxval(const void *s1, const void *s2)
{
	// compare to sort tile numbers
	unsigned *u1 = (unsigned *)s1;
	unsigned *u2 = (unsigned *)s2;
	unsigned yx1 = *u1;
	unsigned yx2 = *u2;
	unsigned y1 = yx1>>16;
	unsigned y2 = yx2>>16;
	if (y1 < y2)  return -1;
	if (y1 > y2)  return 1;
	yx1 &= 0xffff;
	yx2 &= 0xffff;
	if (yx1 < yx2)  return -1;
	if (yx1 > yx2)  return 1;
	return 0;
}

static int CreateValidEntireTileInfo(TGRPINFO *tgi, unsigned **ptnum)
{
	int nrec = 0;
#define MEMALLOCUNIT 1024
	unsigned *yxbuf = NULL;
	int memalloc = 0;
	for (int i = 0 ; i < tgi->numGroups ; i++) {
		unsigned yt = (tgi->grpInfo[i].groupNum>>16)*GRPSIZE;
		unsigned xt = (tgi->grpInfo[i].groupNum&0xffff)*GRPSIZE;
		if (tgi->grpInfo[i].fileOffset == 0xffffffff) {
			for (int y = 0 ; y < GRPSIZE ; y++) {
				for (int x = 0 ; x < GRPSIZE ; x++) {
					if (memalloc <= nrec) {
						memalloc += MEMALLOCUNIT;
						while (1) {
							unsigned *tmpbuf = (unsigned *)realloc(yxbuf, sizeof(unsigned)*memalloc);
							if (tmpbuf) {
								yxbuf = tmpbuf;
								break;
							}
							usleep(100000);
						}
					}
					yxbuf[nrec] = ((yt+y)<<16)|(xt+x);
					nrec++;
				}
			}
		} else {
			fseek(tgi->fp, tgi->grpInfo[i].fileOffset, SEEK_SET);
			unsigned char grpbuf[GRPSIZE*GRPSIZE/8];
			fread(grpbuf, GRPSIZE, GRPSIZE/8, tgi->fp);
			for (int y = 0 ; y < GRPSIZE ; y++) {
				for (int x = 0 ; x < GRPSIZE/8 ; x++) {
					unsigned char mask = 0x80;
					unsigned char dat = grpbuf[y*GRPSIZE/8+x];
					for (int m = 0 ; m < 8 ; m++) {
						if (dat & mask) {
							if (memalloc <= nrec) {
								memalloc += MEMALLOCUNIT;
								while (1) {
									unsigned *tmpbuf = (unsigned *)realloc(yxbuf, sizeof(unsigned)*memalloc);
									if (tmpbuf) {
										yxbuf = tmpbuf;
										break;
									}
									usleep(100000);
								}
							}
							yxbuf[nrec] = ((yt+y)<<16)|(xt+x*8+m);
							nrec++;
						}
						mask >>= 1;
					}
				}
			}
		}
	}
	qsort(yxbuf, nrec, sizeof(unsigned), _cmpyxval);
	*ptnum = yxbuf;
	return nrec;
#undef MEMALLOCUNIT
}

#define MAPFILEREQ_EXIT -1
#define MAPFILEREQ_TILEPOSESSION -2
#define MAPFILEREQ_VALIEDTILE -3

static THREADTYP MapFileReadThread(THREADARG tprm)
{
    MAPCTRL *mc = (MAPCTRL *)tprm;
    FACCTHREADCTRL *facc = (FACCTHREADCTRL *)&mc->m_facc;
    THREADCTRL *tct = &facc->m_tct;
    while (1) {
        MUTEXLOCK(tct->m_mtxnew);
        if (!facc->m_nreq) {
            CONDWAIT(tct->m_cndnew, tct->m_mtxnew);
        }
        int nreq = facc->m_nreq;
        facc->m_nreq = 0;
        MUTEXUNLOCK(tct->m_mtxnew);
        if (nreq == MAPFILEREQ_EXIT) {
            break;
        }
		MUTEXUNLOCK(tct->m_mtxfile);
    }
    MUTEXLOCK(tct->m_mtxrdy[0]);
    facc->m_numrdy = (int *)-1;  // signify I'm done
    CONDSIG(tct->m_cndrdy[0]);
    MUTEXUNLOCK(tct->m_mtxrdy[0]);
    return 0;
}

int RequestEntireMapTilePossessionInfo(const MAPOBJ *mobj, unsigned **ptlist)
{
	MAPDATCTRL *md = (MAPDATCTRL *)mobj;
	MAPGRP *mg = (MAPGRP *)md->mgrp;
	MAPCTRL *mc = (MAPCTRL *)mg->m_mapctrl;
	FACCTHREADCTRL *facc = &mc->m_facc;
	THREADCTRL *ftct = &facc->m_tct;  // file access thread control
	MUTEXLOCK(ftct->m_mtxfile);
	facc->m_md = md;
	*ptlist = NULL;
	facc->m_tnum = (unsigned *)ptlist;
	volatile int numrdy = 0;
	facc->m_numrdy = (int *)&numrdy;
	facc->m_notifyIdx = 1;
	MUTEXLOCK(ftct->m_mtxnew);
	facc->m_nreq = MAPFILEREQ_TILEPOSESSION;  // see MapFileReadThread() for this
	CONDSIG(ftct->m_cndnew);
	MUTEXUNLOCK(ftct->m_mtxnew);
	MUTEXLOCK(ftct->m_mtxrdy[1]);
	CONDWAIT(ftct->m_cndrdy[1], ftct->m_mtxrdy[1]);
	MUTEXUNLOCK(ftct->m_mtxrdy[1]);
	return numrdy;
}

int RequestEntireValidMapTileInfo(const MAPOBJ *mobj, unsigned **ptlist, int sync)
{
	MAPDATCTRL *md = (MAPDATCTRL *)mobj;
	int numrdy = 0;
	numrdy = CreateValidEntireTileInfo(md->tgi, ptlist);
	return numrdy;
}

static THREADTYP TileDataGenThread(THREADARG tprm)
{
    MAPCTRL *mc = (MAPCTRL *)tprm;
    TGENTHREADCTRL *tgen = &mc->m_tgen;
    THREADCTRL *ttct = &tgen->m_tct;  // tile gen thread control
    while (1) {
        MUTEXLOCK(ttct->m_mtxnew);
        if (!tgen->m_cmd) {
            CONDWAIT(ttct->m_cndnew, ttct->m_mtxnew);
        }
        int cmd = tgen->m_cmd;
        MUTEXUNLOCK(ttct->m_mtxnew);
        if (cmd == -1) {
            break;  // terminate request
        }
        tgen->m_cmd = 0;
    }
    MUTEXLOCK(ttct->m_mtxrdy[0]);
    tgen->m_cmd = -2;  // this to notify I'm done
    CONDSIG(ttct->m_cndrdy[0]);
    MUTEXUNLOCK(ttct->m_mtxrdy[0]);
    return 0;
}

int GetPrivateProfileStr(const char *sect, const char *key, const char *defstr, char *srtn, int nSize, const char *inifile)
{
    int deflen = (int)strlen(defstr);
    nSize--;  // this for terminating NULL
    if (deflen > nSize)  deflen = nSize;
    FILE *fp = fopen(inifile, "r");
    if (!fp) {
        strncpy(srtn, defstr, deflen);
        srtn[deflen] = '\0';
        return deflen;
    }
    char linbuf[4096];
    int found = 0;
    while (fgets(linbuf, sizeof(linbuf), fp)) {
        if (linbuf[0] != '[')  continue;
        char *p = strchr(linbuf+1, ']');
        if (!p)  continue;
        *p = 0;
        if (!strcmp(linbuf+1, sect)) {
            found = 1;
            break;
        }
    }
    if (!found) {
        fclose(fp);
        strncpy(srtn, defstr, deflen);
        srtn[deflen] = '\0';
        return deflen;
    }
    found = 0;
    char *p = NULL;
    while (fgets(linbuf, sizeof(linbuf), fp)) {
        if (linbuf[0] == '[')  break;
        p = strchr(linbuf, '=');
        if (!p)  continue;
        *p = '\0';
        if (!strcmp(key, linbuf)) {
            found = 1;
            break;
        }
    }
    fclose(fp);
    if (!found) {
        strncpy(srtn, defstr, deflen);
        srtn[deflen] = '\0';
        return deflen;
    }
    p++;
    char *t = p + strlen(p) - 1;
    if (*t == '\r' || *t == '\n')  *t-- = '\0';
    if (*t == '\r' || *t == '\n')  *t-- = '\0';
    while (t >= p && (*t == ' ' || *t == '\t'))  *t-- = '\0';
    int slen = (int)strlen(p);
    if (slen > nSize)  slen = nSize;
    strncpy(srtn, p, slen);
    srtn[slen] = '\0';
    return slen;
}

TGRPINFO *initGrpInfo(const char *infofile) {
	FILE *fp = fopen(infofile, "rb");
	if (!fp)  return NULL;
	TGRPINFO *tgi;
	while (1) {
		tgi = (TGRPINFO *)malloc(sizeof(TGRPINFO));
		if (tgi)  break;
		usleep(100000);
	}
	tgi->fp = fp;
	fread(&tgi->numGroups, sizeof(unsigned), 1, fp);
	while (1) {
		tgi->grpInfo = (GRPINFO *)malloc(sizeof(GRPINFO)*tgi->numGroups);
		if (tgi->grpInfo)  break;
	}
	fread(tgi->grpInfo, sizeof(GRPINFO), tgi->numGroups, fp);
	for (int i = 0 ; i < NUMGRPCACHE ; i++) {
		tgi->groupNum[i] = 0xffffffff;
		tgi->groupIdx[i] = i;
	}
	return tgi;
}

void destroyGrpInfo(TGRPINFO *tgi) {
	if (!tgi)  return;
	fclose(tgi->fp);
	free(tgi->grpInfo);
	free(tgi);
}

unsigned *RequestColorTable(const MAPOBJ *mobj)
{
	MAPGRP *mg = mobj->mgrp;
	return mg->m_mi[mobj->m_idx].m_coltbl;
}

MAPOBJ *CreateMapObjWithNoMapdata(const MAPGRP *mg, int scidx)
{
	if (scidx >= mg->m_nscales)  return NULL;
	char filename[MAX_PATH];
	strcpy(filename, mg->m_mapdir);
	char *fname = filename+strlen(filename);
	sprintf(fname, "%d/", (int)mg->m_mi[scidx].m_scale);
	fname = fname+strlen(fname);
	strcpy(fname, GRPFILE);
	TGRPINFO *tgi = NULL;
	if (mg->m_tgi[scidx]) {
		tgi = mg->m_tgi[scidx];
	} else {
		tgi = initGrpInfo(filename);
	}
	if (!tgi) {
		return NULL;
	}
	MAPDATCTRL *md;
	while (1) {
		md = (MAPDATCTRL *)moCalloc(1, sizeof(MAPDATCTRL));
		if (md)  break;
		usleep(100000);
	}
	strcpy(fname, COLTBLFILE);
	FILE *fpcol = fopen(filename, "rb");
	if (!fpcol) {
		free(md);
		return NULL;
	}
	fread(mg->m_mi[scidx].m_coltbl, sizeof(unsigned), 256, fpcol);
	fclose(fpcol);
	md->tgi = tgi;
	md->mgrp = (MAPGRP *)mg;
	md->m_idx = scidx;
	return md;
}

void DestroyMapObj(const MAPOBJ *mo)
{
	destroyGrpInfo(mo->tgi);
	if (mo->fpIdx)  fclose(mo->fpIdx);
	if (mo->fpDat)  fclose(mo->fpDat);
	for (int i = 0 ; i < mo->numCache ; i++) {
		moFree(mo->tcache[i]);
	}
	MAPGRP *mg = (MAPGRP *)mo->mgrp;
	mg->m_mi[mo->m_idx].m_mapdat = NULL;
	moFree((MAPOBJ *)mo);
}

void DestroyMapGrp(const MAPGRP *mg)
{
    MAPCTRL *mc = (MAPCTRL *)mg->m_mapctrl;
    int found = 0;
    for (int i = 0 ; i < mc->m_nmapgrp ; i++) {
        if (mc->m_mapgrp[i] == mg) {
            mc->m_nmapgrp--;
            for (int j = i ; j < mc->m_nmapgrp ; j++) {
                mc->m_mapgrp[j] = mc->m_mapgrp[j+1];
            }
            if (mc->m_nmapgrp) {
				while (1) {
					MAPGRP **mgrptmp = (MAPGRP **)realloc(mc->m_mapgrp, sizeof(MAPGRP *)*mc->m_nmapgrp);
					if (mgrptmp) {
						mc->m_mapgrp = mgrptmp;
						break;
					}
					usleep(100000);
				}
            } else {
                moFree(mc->m_mapgrp);
                mc->m_mapgrp = NULL;
            }
            found = 1;
            break;
        }
        if (found)  break;
    }
    for (int i = 0 ; i < mg->m_nscales ; i++) {
        if (mg->m_mi[i].m_mapdat) {
            DestroyMapObj(mg->m_mi[i].m_mapdat);
        }
    }
    moFree(mg->m_mi);
    moFree(mg->m_mapdir);
	for (int i = 0 ; i <mg->m_nscales ; i++) {
		if (mg->m_tgi[i])  destroyGrpInfo(mg->m_tgi[i]);
	}
	moFree(mg->m_tgi);
    moFree((MAPGRP *)mg);
    TILECACHE *cache = &mc->m_cache;
    for (int i = 0 ; i < cache->m_numTileCache ; i++) {
        if (cache->m_tileLen[i])  moFree(cache->m_ctile[i]);
    }
    cache->m_numTileCache = 0;
}

static void FreeMAPGRPMem(MAPGRP *mg)
{
    if (mg->m_mapdir)  moFree(mg->m_mapdir);
}

MAPGRP *CreateMapGrp(MAPCTRL *mc, const char *grpname)
{
#define MAPDESCFILE "mapdesc.ini"
    char filepath[MAX_PATH];
    strcpy(filepath, mc->m_rootdir);
    int len = (int)strlen(filepath);
    strcpy(filepath+len, grpname);
    len = (int)strlen(filepath);
    if (filepath[len-1] != '/')  filepath[len++] = '/';
    char *maproot = filepath+len;
    strcpy(maproot, MAPDESCFILE);
    char tmpbuf[128];
    MAPGRP mgrp;
    memset(&mgrp, 0, sizeof(MAPGRP));
    const char *gsect = "GENERAL";
    GetPrivateProfileStr(gsect, "numScales", "0", tmpbuf, sizeof(tmpbuf), filepath);
    mgrp.m_nscales = atoi(tmpbuf);
    if (mgrp.m_nscales <= 0)  return NULL;
	while (1) {
		mgrp.m_mi = (MAPINFO *)moCalloc(sizeof(MAPINFO), mgrp.m_nscales);
		if (mgrp.m_mi)  break;
		usleep(100000);
	}
	while (1) {
		mgrp.m_tgi = (TGRPINFO **)moCalloc(sizeof(TGRPINFO *), mgrp.m_nscales);
		if (mgrp.m_tgi)  break;
		usleep(100000);
	}
    GetPrivateProfileStr(gsect, "zoom", "100", tmpbuf, sizeof(tmpbuf), filepath);
    mgrp.m_zoom = atof(tmpbuf)/100.0;
    GetPrivateProfileStr(gsect, "datum", "WGS84", tmpbuf, sizeof(tmpbuf), filepath);
    if (!strcmp(tmpbuf, "TOKYO")) {
        mgrp.m_datum = DATUM_TOKYO;
    } else {
        mgrp.m_datum = DATUM_WGS84;
    }
	GetPrivateProfileStr(gsect, "mapSystemScale", "0.5", tmpbuf, sizeof(tmpbuf), filepath);
	mgrp.m_systemScale = atof(tmpbuf);
	GetPrivateProfileStr(gsect, "downLoadScale", "-1", tmpbuf, sizeof(tmpbuf), filepath);
	mgrp.m_downloadScale = atoi(tmpbuf);
	GetPrivateProfileStr(gsect, "downLoadDispScale", "-1", tmpbuf, sizeof(tmpbuf), filepath);
	mgrp.m_downloadDispScale = atoi(tmpbuf);
	GetPrivateProfileStr(gsect, "downLoadMaxZoomScaleAtDispMap", "3.0", tmpbuf, sizeof(tmpbuf), filepath);
	mgrp.m_downloadMaxZoomAtDispMap = atoi(tmpbuf);
	GetPrivateProfileStr(gsect, "minZoomAtMaxMap", "0.7", tmpbuf, sizeof(tmpbuf), filepath);
	mgrp.m_minZoomAtMaxMap = atof(tmpbuf);
	GetPrivateProfileStr(gsect, "maxZoomAtMinMap", "2.0", tmpbuf, sizeof(tmpbuf), filepath);
	mgrp.m_maxZoomAtMinMap = atof(tmpbuf);
    // get bpp
    const char *csect = "COLOR";
    GetPrivateProfileStr(csect, "BPP", "0", tmpbuf, sizeof(tmpbuf), filepath);
    mgrp.m_bpp = atoi(tmpbuf);
    if (mgrp.m_bpp != 4 && mgrp.m_bpp != 8) {
        FreeMAPGRPMem(&mgrp);
        return NULL;
    }
    int tblEntries = (1<<mgrp.m_bpp);
    // get scales, etc.
    const char *psect = "PROJ";
    char scalestr[16];
    char oceanstr[16];
    char latstr[16];
    char lonstr[16];
    char prjstr[16];
    char maxxtilestr[16];
    char maxytilestr[16];
#define SCALESTR "scale"
#define OCEANSTR "ocean"
#define LATSTR "lat"
#define LONSTR "lon"
#define PRJSTR "proj"
#define MAXXSTR "xmaxtile"
#define MAXYSTR "ymaxtile"
    strcpy(scalestr, SCALESTR);
    strcpy(oceanstr, OCEANSTR);
    strcpy(latstr, LATSTR);
    strcpy(lonstr, LONSTR);
    strcpy(prjstr, PRJSTR);
    strcpy(maxxtilestr, MAXXSTR);
    strcpy(maxytilestr, MAXYSTR);
#define SCALE_NUM_POS 5
#define OCEAN_NUM_POS 5
#define LAT_NUM_POS 3
#define LON_NUM_POS 3
#define PRJ_NUM_POS 4
#define MAXTILE_NUM_POS 8
	char key[16];
	for (int i = 0 ; i < mgrp.m_nscales ; i++) {
        sprintf(scalestr+SCALE_NUM_POS, "%d", i);
        GetPrivateProfileStr("SCALE", scalestr, "0", tmpbuf, sizeof(tmpbuf), filepath);
        mgrp.m_mi[i].m_scale = atof(tmpbuf);
        sprintf(oceanstr+OCEAN_NUM_POS, "%d", i);
        GetPrivateProfileStr(csect, oceanstr, "0", tmpbuf, sizeof(tmpbuf), filepath);
        mgrp.m_mi[i].m_ocean = atoi(tmpbuf);
        if (mgrp.m_mi[i].m_ocean >= tblEntries)  mgrp.m_mi[i].m_ocean = 0;
        sprintf(latstr+LAT_NUM_POS, "%d", i);
        GetPrivateProfileStr("ORIGIN", latstr, "0", tmpbuf, sizeof(tmpbuf), filepath);
        mgrp.m_mi[i].m_orglat = atoi(tmpbuf);
        sprintf(lonstr+LON_NUM_POS, "%d", i);
        GetPrivateProfileStr("ORIGIN", lonstr, "0", tmpbuf, sizeof(tmpbuf), filepath);
        mgrp.m_mi[i].m_orglon = atoi(tmpbuf);
        GetPrivateProfileStr(psect, latstr, "0", tmpbuf, sizeof(tmpbuf), filepath);
        mgrp.m_mi[i].m_prjlat = atoi(tmpbuf);
        GetPrivateProfileStr(psect, lonstr, "0", tmpbuf, sizeof(tmpbuf), filepath);
        mgrp.m_mi[i].m_prjlon = atoi(tmpbuf);
        sprintf(prjstr+PRJ_NUM_POS, "%d", i);
        GetPrivateProfileStr(psect, prjstr, "", tmpbuf, sizeof(tmpbuf), filepath);
        if (!strcmp(tmpbuf, "Merc")) {
            mgrp.m_mi[i].m_proj = PRJ_MERC;
        } else {
            mgrp.m_mi[i].m_proj = PRJ_TMERC;
        }
		mgrp.m_mi[i].m_pp.clat = LONG2RAD(mgrp.m_mi[i].m_prjlat);
		mgrp.m_mi[i].m_pp.clon = LONG2RAD(mgrp.m_mi[i].m_prjlon);
		sprintf(key, "RE%d", i);
		GetPrivateProfileStr(psect, key, "0", tmpbuf, sizeof(tmpbuf), filepath);
		mgrp.m_mi[i].m_pp.re = atof(tmpbuf);
		sprintf(key, "RP%d", i);
		GetPrivateProfileStr(psect, key, "0", tmpbuf, sizeof(tmpbuf), filepath);
		mgrp.m_mi[i].m_pp.rp = atof(tmpbuf);
		sprintf(key, "K%d", i);
		GetPrivateProfileStr(psect, key, "0", tmpbuf, sizeof(tmpbuf), filepath);
		mgrp.m_mi[i].m_pp.k0 = atof(tmpbuf);
		calcProjParm(&mgrp.m_mi[i].m_pp);
        mgrp.m_mi[i].m_xyscale = (1000.0 * 10.0 / mgrp.m_mi[i].m_scale) * mgrp.m_zoom;  // 1000mm = 1m, 10dot/mm
 		(*g_prjfunc[mgrp.m_mi[i].m_proj])(MSEC2RAD(mgrp.m_mi[i].m_orglat), MSEC2RAD(mgrp.m_mi[i].m_orglon), &mgrp.m_mi[i].m_xorg, &mgrp.m_mi[i].m_yorg, &mgrp.m_mi[i].m_pp);
        sprintf(maxxtilestr+MAXTILE_NUM_POS, "%d", i);
        GetPrivateProfileStr("MAXTILE", maxxtilestr, "", tmpbuf, sizeof(tmpbuf), filepath);
        mgrp.m_mi[i].m_xmaxtile = atoi(tmpbuf);
        sprintf(maxytilestr+MAXTILE_NUM_POS, "%d", i);
        GetPrivateProfileStr("MAXTILE", maxytilestr, "", tmpbuf, sizeof(tmpbuf), filepath);
        mgrp.m_mi[i].m_ymaxtile = atoi(tmpbuf);
    }
    *maproot = '\0';
    int dirlen = (int)strlen(filepath) + 1;
	while (1) {
		mgrp.m_mapdir = (char *)moMalloc(dirlen);
		if (mgrp.m_mapdir)  break;
		usleep(100000);
    }
    strcpy(mgrp.m_mapdir, filepath);
    mgrp.m_mapctrl = mc;
	MAPGRP *mgo;
	while (1) {
		mgo = (MAPGRP *)moMalloc(sizeof(MAPGRP));
		if (mgo)  break;
		usleep(100000);
	}
	*mgo = mgrp;
	MAPGRP **mgrptmp;
	while (1) {
		mgrptmp = (MAPGRP **)realloc(mc->m_mapgrp, sizeof(MAPGRP *)*(mc->m_nmapgrp+1));
		if (mgrptmp)  break;
		usleep(100000);
    }
    mc->m_mapgrp = mgrptmp;
    mc->m_mapgrp[mc->m_nmapgrp] = mgo;
    mc->m_nmapgrp++;
    return mgo;
}

static void CreateThreadObj(MAPCTRL *mc)
{
    MUTEXCREATE(mc->m_facc.m_tct.m_mtxnew);
    CONDCREATE(mc->m_facc.m_tct.m_cndnew);
	MUTEXCREATE(mc->m_facc.m_tct.m_mtxrdy[0]);
	CONDCREATE(mc->m_facc.m_tct.m_cndrdy[0]);
	MUTEXCREATE(mc->m_facc.m_tct.m_mtxrdy[1]);
	CONDCREATE(mc->m_facc.m_tct.m_cndrdy[1]);
	MUTEXCREATE(mc->m_facc.m_tct.m_mtxfile);
    THREADCREATE(MapFileReadThread, mc);
    MUTEXCREATE(mc->m_tgen.m_tct.m_mtxnew);
    CONDCREATE(mc->m_tgen.m_tct.m_cndnew);
    MUTEXCREATE(mc->m_tgen.m_tct.m_mtxrdy[0]);
    CONDCREATE(mc->m_tgen.m_tct.m_cndrdy[0]);
    THREADCREATE(TileDataGenThread, mc);
}

static void DestroyThreadObj(MAPCTRL *mc)
{
    FACCTHREADCTRL *facc = &mc->m_facc;
    THREADCTRL *ftct = &facc->m_tct;
    MUTEXLOCK(ftct->m_mtxnew);
    facc->m_nreq = -1;  // this to tell thread to exit
    CONDSIG(ftct->m_cndnew);
    MUTEXUNLOCK(ftct->m_mtxnew);
    MUTEXLOCK(ftct->m_mtxrdy[0]);
    if (facc->m_numrdy != (int *)-1) {
        CONDWAIT(ftct->m_cndrdy[0], ftct->m_mtxrdy[0]);
    }
    MUTEXUNLOCK(ftct->m_mtxrdy[0]);
    MUTEXDESTROY(ftct->m_mtxnew);
    CONDDESTROY(ftct->m_cndnew);
	MUTEXDESTROY(ftct->m_mtxrdy[0]);
	CONDDESTROY(ftct->m_cndrdy[0]);
	MUTEXDESTROY(ftct->m_mtxrdy[1]);
	CONDDESTROY(ftct->m_cndrdy[1]);
	MUTEXDESTROY(ftct->m_mtxfile);
    TGENTHREADCTRL *tgen = &mc->m_tgen;
    THREADCTRL *ttct = &tgen->m_tct;
    MUTEXLOCK(ttct->m_mtxnew);
    tgen->m_cmd = -1;  // this to tell thread to exit
    CONDSIG(ttct->m_cndnew);
    MUTEXUNLOCK(ttct->m_mtxnew);
    MUTEXLOCK(ttct->m_mtxrdy[0]);
    if (tgen->m_cmd != -2) {
        CONDWAIT(ttct->m_cndrdy[0], ttct->m_mtxrdy[0]);
    }
    MUTEXUNLOCK(ttct->m_mtxrdy[0]);
    MUTEXDESTROY(ttct->m_mtxnew);
    CONDDESTROY(ttct->m_cndnew);
    MUTEXDESTROY(ttct->m_mtxrdy[0]);
    CONDDESTROY(ttct->m_cndrdy[0]);
    TILECACHE *cache = &mc->m_cache;
    for (int i = 0 ; i < cache->m_numTileCache ; i++) {
        if (cache->m_tileLen[i]) {
            moFree(cache->m_ctile[i]);
            cache->m_ctile[i] = NULL;
        }
    }
    cache->m_numTileCache = 0;
    DECOMPCACHE *dcach = &mc->m_dcache;
    for (int i = 0 ; i < dcach->m_numDecompCache ; i++) {
        moFree(dcach->m_dtile[i]);
        dcach->m_dtile[i] = NULL;
    }
    dcach->m_numDecompCache = 0;
}

MAPCTRL *CreateMapCtrl(const char *rootdir)
{
	moMemInit();
	MAPCTRL *mc;
	while (1) {
		mc = (MAPCTRL *)moCalloc(sizeof(MAPCTRL), 1);
		if (mc)  break;
		usleep(100000);
	}
    int slen = (int)strlen(rootdir);
	char *dir;
	while (1) {
		dir = (char *)moMalloc(strlen(rootdir)+2);
		if (dir)  break;
		usleep(100000);
    }
    strcpy(dir, rootdir);
    if (dir[slen-1] != '/') {
        dir[slen++] = '/';
        dir[slen] = '\0';
    }
    mc->m_rootdir = dir;
    CreateThreadObj(mc);
    return mc;
}

void DestroyMapCtrl(MAPCTRL *mc)
{
    DestroyThreadObj(mc);
    int nmapgrp = mc->m_nmapgrp;
    for (int i = 0 ; i < nmapgrp ; i++) {
        DestroyMapGrp(mc->m_mapgrp[i]);
    }
    moFree(mc->m_rootdir);
    moFree(mc);
}
