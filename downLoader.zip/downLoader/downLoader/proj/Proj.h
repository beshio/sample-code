#pragma once

#ifndef _USE_MATH_DEFINES
#define _USE_MATH_DEFINES
#endif
#include <math.h>

// mSec(int)をラジアン(double)に
#define LONG2RAD(l) ((double)(l)*(M_PI/(180.0*3600.0*1000.0)))

#ifndef DEG2LONG
// dd mm ss.ss形式度分秒(LONG[4])をmSec(LONG)に
#define DEG2LONG(deg) ((deg)[0]*3600*1000+(deg)[1]*60*1000+(deg)[2]*1000+(deg)[3]*10)
#endif
// mSec(double)をラジアン(double)に
#define MSEC2RAD(l) ((double)(l)*(M_PI/(180.0*3600.0*1000.0)))
// ラジアン(doble)をmSec(double)に
#define RAD2MSEC(r) ((r)*180.0/M_PI*3600*1000)
// mSec(LONG)をdd mm ss.ss形式度分秒(LONG[4])に
#define LONG2DEG(l,deg) {\
	int __tmp = l;\
	(deg)[0] = __tmp/(60*60*1000);\
	__tmp -= (deg)[0] * 60*60*1000;\
	(deg)[1] = __tmp/(60*1000);\
	__tmp -= (deg)[1] * 60*1000;\
	(deg)[2] = __tmp/1000;\
	(deg)[3] = __tmp - (deg)[2]*1000;\
}

#define DMSSS(d,m,s,ss) ((d)*3600000+(m)*60000+(s)*1000+(ss))	// 度分秒よりミリ秒へ
#define DEG2MSEC(d) ((d)*3600000)	// 度よりミリ秒へ
#define DEG2RAD(d)	((d)/180.0*M_PI)	// 度をラジアンに変換
#define MSEC2DEG(m) ((m)/3600000)	// mSec to deg

// parms for projection
typedef struct {
	double re;			// 赤道半径(equitorial radius) [m], given == a
	double rp;			// 極半径(polar radius) [m], given, == b
	double clat;		// projection origin latitude [radian], given
	double clon;		// projection origin longitude [radian], given
	double k0;			// 縮率 or any scaling, given
	int sphere;			// 1 if spere ==> means re = rp
	// sphere parm
	double k0_ms;		// = k0 * cos(clat)
	double mercs_yoffset;	// y offset for mercator at sphere
	// ellipsoid parm
	double e;			// 離心率 = sqrt((a*a-b*b)/(a*a))
	double es;			// 離心率(eccentricity)**2
	double es2;			// 第2離心率**2
	double en[5];
	double k0_me;		// = K0 * RE * c / sqrt(1.0-ES*s*s), c = cos(clon), s = sin(clat)
	double merce_yoffset;	// y offset for mercator at ellips
	double tmerc_latoff;	// = en[0]*p-c*s*(en[1]+ss*(en[2]+ss*(en[3]+ss*en[4]))), c=cos(clat), s=sin(clat), ss=s*s
} PROJPARM;

void Rad2MercS(double Lon, double Lat, double *xMerc, double *yMerc);
void Merc2RadS(double xMerc, double yMerc, double *pLat, double *pLon);
void Rad2MercE(double Lat, double Lon, double *xMerc, double *yMerc);
void Merc2RadE(double xMerc, double yMerc, double *pLat, double *pLon);
void Rad2TMercWithCenter(double Lat, double Lon, double *xTMerc, double *yTMerc, double clat, double clon);
void wgs2tokyo(double wgsLat, double wgsLon, double *tkyLat, double *tkyLon);
void tokyo2wgs(double tkyLat, double tkyLon, double *wgsLat, double *wgsLon);
int Deg2Int(int deg0, int deg1, int deg2, int deg3);

void calcProjParm(PROJPARM *pp);
void Rad2Merc(double Lat, double Lon, double *xMerc, double *yMerc, PROJPARM *pp);
void Merc2Rad(double xMerc, double yMerc, double *pLat, double *pLon, PROJPARM *pp);
void Rad2TMerc(double Lat, double Lon, double *xTMerc, double *yTMerc,PROJPARM *pp);
void TMerc2Rad(double xTMerc, double yTMerc, double *Lat, double *Lon, PROJPARM *pp);

void projtest();
