//
// 地図の座標投影変換を行う
//

#include "Proj.h"

// 座標の計算を行うための定数
#define FC1	1.0
#define FC2	0.5
#define FC3	0.16666666666666666666
#define FC4	0.08333333333333333333
#define FC5	0.05
#define FC6	0.03333333333333333333
#define FC7	0.02380952380952380952
#define FC8	0.01785714285714285714

// 楕円体の経線長に対応する角度を計算するための定数
#define C00	1.0
#define C02	0.25
#define C04	0.046875
#define C06	0.01953125
#define C08	0.01068115234375
#define C22	0.75
#define C44	0.46875
#define C46	0.01302083333333333333
#define C48	0.00712076822916666666
#define C66	0.36458333333333333333
#define C68	0.00569661458333333333
#define C88	0.3076171875

// init PROJPARM struc
// at entry you need to set re: equitorial radius, rp: polar radius, clat: projection origin latitude, clon: projection origin longitude
// and k0: scaling
//
void calcProjParm(PROJPARM *pp) {
	pp->sphere = (pp->re == pp->rp);
	// precompute offset values, etc.
	if (!pp->sphere) {
		// parm for ellipsoid
		double re2 = pp->re*pp->re;
		double es = (re2 - pp->rp*pp->rp)/re2;  // eccentricity
		pp->es = es;
		pp->e = sqrt(es);
		pp->es2 = es/(1.0-es);
		pp->en[0] = (C00 - es * (C02 + es * (C04 + es * (C06 + es * C08))));
		pp->en[1] = (es * (C22 - es * (C04 + es * (C06 + es * C08))));
		pp->en[2] = (es * es * (C44 - es * (C46 + es * C48)));
		pp->en[3] = (es * es * es * (C66 - es * C68));
		pp->en[4] = (es * es * es * es * C88);
		double cp = cos(pp->clat);
		double sp = sin(pp->clat);
		double ssp = sp*sp;
		pp->tmerc_latoff = pp->en[0]*pp->clat-cp*sp*(pp->en[1]+ssp*(pp->en[2]+ssp*(pp->en[3]+ssp*pp->en[4])));
		pp->k0_me = pp->k0 * pp->re * cp/sqrt(1.0-es*ssp);
		double s = sp * pp->e;
		double z = tan(0.5 * (M_PI_2 - pp->clat)) / pow((1.0 - s) / (1.0 + s), 0.5 * pp->e);
		pp->merce_yoffset = -pp->k0_me * log(z);
	} else {
		// parm for sphere
		pp->k0_ms = pp->k0 * pp->re*cos(pp->clat);
		pp->mercs_yoffset = pp->k0_ms * log(tan(M_PI_4 + 0.5 * pp->clat));
	}
}

// lat/lon [radian] to x/y mercator [m]
//
void Rad2Merc(double Lat, double Lon, double *xMerc, double *yMerc, PROJPARM *pp)
{
	if (pp->sphere) {
		// sphere
		*xMerc = pp->k0_ms * (Lon - pp->clon);
		*yMerc = pp->k0_ms * log(tan(M_PI_4 + 0.5 * Lat)) - pp->mercs_yoffset;
	} else {
		// ellipsoid
		*xMerc = pp->k0_me * (Lon - pp->clon);
		double s = sin(Lat) * pp->e;
		double z = tan(0.5 * (M_PI_2 - Lat)) / pow((1.0 - s) / (1.0 + s), 0.5 * pp->e);
		*yMerc = -pp->k0_me * log(z) - pp->merce_yoffset;
	}
}

// x/y mercator [m] to lat/lon [radian]
//
void Merc2Rad(double xMerc, double yMerc, double *pLat, double *pLon, PROJPARM *pp)
{
	if (pp->sphere) {
		*pLon = xMerc / pp->k0_ms + pp->clon;
		yMerc += pp->mercs_yoffset;
		*pLat = M_PI_2 - 2.0 * atan(exp(-yMerc/pp->k0_ms));
	} else {
#define TOL 1.0e-10
#define N_ITER 15
		yMerc += pp->merce_yoffset;
		double ts = exp(-yMerc/pp->k0_me);
		double phi = M_PI_2 - 2.0*atan(ts);
		for (int i = 0 ; i < N_ITER ; i++) {
			double con = pp->e * sin(phi);
			double dphi = M_PI_2 - 2.0 * atan(ts * pow((1.0-con)/(1.0+con), 0.5*pp->e)) - phi;
			phi += dphi;
			if (fabs(dphi) <= TOL)  break;
		}
		*pLat = phi;
		*pLon = xMerc / pp->k0_me + pp->clon;
#undef TOL
#undef N_ITER
	}
}

// lat/lon [radian] to x/y transverse mercator [m]
//
// NOTE: for now ONLY ellipsoid is implemented
//
void Rad2TMerc(double Lat, double Lon, double *xTMerc, double *yTMerc,PROJPARM *pp)
{
#define EPS 1e-10
	if (pp->sphere) {
		return;
	} else {
		double phi = Lat;
		double lam = Lon - pp->clon;  // 中心の経度のゲタを差っ引く
		double s = sin(phi);
		double c = cos(phi);
		double t = fabs(c) > EPS ? s/c : 0.0;
		t *= t;
		double al = c * lam;
		double als = al * al;
		al /= sqrt(1.0 - pp->es * s * s);
		double k0_re = pp->k0*pp->re;
		double n = pp->es2 * c * c;
		*xTMerc = k0_re * al * (FC1 + FC3 * als * (1.0 - t + n + FC5 * als * (5.0 + t * (t - 18.0) + n * (14.0 - 58.0 * t)
																			  + FC7 * als * (61.0 + t * (t * (179.0 - t) - 479.0)))));
		double ss = s * s;
		double z = pp->en[0] * phi - c * s * (pp->en[1] + ss * (pp->en[2] + ss * (pp->en[3] + ss*pp->en[4]))) - pp->tmerc_latoff;
		*yTMerc = k0_re * (z + s * al * lam * FC2 * (1.0 + FC4 * als * (5.0 - t + n * (9.0 + 4.0 * n) +
																		FC6 * als * (61.0 + t * (t - 58.0) + n * (270.0 - 330.0 * t)
																					 + FC8 * als * (1385.0 + t * (t * (543.0 - t) - 3111.0))))));
	}
#undef EPS
}

// x/y transverse mercator [m] to lat/lon [radian]
//
// NOTE: for now ONLY ellipsoid is implemented
//
void TMerc2Rad(double xTMerc, double yTMerc, double *Lat, double *Lon, PROJPARM *pp)
{
#define MAX_ITER 10
#define EPS 1e-10
	if (pp->sphere) {
		return;
	} else {
		double x = xTMerc / pp->re;
		double y = yTMerc / pp->re;
		double phi, arg;
		phi = arg = pp->tmerc_latoff + y / pp->k0;
		for (int i = 0 ; i < MAX_ITER ; i++) {
			double s = sin(phi);
			double c = cos(phi);
			c *= s;
			s *= s;
			double t = 1.0 - pp->es * s;
			double z = pp->en[0] * phi - c * (pp->en[1] + s * (pp->en[2] + s * (pp->en[3] + s * pp->en[4])));
			t = (z - arg) * (t * sqrt(t)) * (1.0/(1.0-pp->es));
			phi -= t;
			if (fabs(t) < EPS)  break;
		}
		double lam;
		if (fabs(phi) >= M_PI_2) {
			phi = (y < 0.0) ? -M_PI_2 : M_PI_2;
			lam = 0.0;
		} else {
			double s = sin(phi);
			double c = cos(phi);
			double t = fabs(c) > 1e-10 ? s/c : 0.0;
			double n = pp->es2 * c * c;
			double z = 1.0 - pp->es * s * s;
			double d = x * sqrt(z) / pp->k0;
			z *= t;
			t *= t;
			double ds = d * d;
			phi -= (z * ds / (1.0-pp->es)) * FC2 * (1.0 - ds * FC4 * (5.0 + t * (3.0 - 9.0 *  n) + n * (1.0 - 4.0 * n)
																	  - ds * FC6 * (61.0 + t * (90.0 - 252.0 * n + 45.0 * t) + 46.0 * n
																					- ds * FC8 * (1385.0 + t * (3633.0 + t * (4095.0 + 1574.0 * t))))));
			lam = d * (FC1 - ds * FC3 * (1.0 + 2.0 * t + n - ds * FC5 * (5.0 + t * (28.0 + 24.0 * t + 8.0 * n) + 6.0 * n
																		 - ds * FC7 * (61.0 + t * (662.0 + t * (1320.0 + 720.0 * t)))))) / c;
		}
		lam += pp->clon;
		*Lat = phi;
		*Lon = lam;
	}
#undef MAX_ITR
#undef EPS
}

// 座標変換に用いるベッセル楕円体の定数等
#define RE 6377397.155				// 赤道半径
#define RP 6356078.963				// 極半径
#define K0_MS 0.8090169943749473	// 真球(sphere)時に角度->メルカトル変換に用いる係数
// = cos(DEG2RAD(ORG_LAT_MERC))
#define ES ((RE*RE-RP*RP)/(RE*RE))	// 離心率(eccentricity)**2
#define ES2	(ES/(1.0-ES))			// 第2離心率**2
#define E 0.08169683087473426	// = 離心率=sqrt(ES)
#define K0_ME 5165381.642670027		// = RE * c / sqrt(1.0-ES*s*s), c = cos(DEG2RAD(ORG_LAT_MERC)), s = sin(DEG2RAD(ORG_LAT_MERC))
#define IK0_ME	0.8099513825354705	// = c / sqrt(1.0-ES*s*s), c = cos(DEG2RAD(ORG_LAT_MERC)), s = sin(DEG2RAD(ORG_LAT_MERC))

#define K0	0.9996					// 縮率

// 楕円体の経線長に対応する角度を計算するための定数
#define EN0	(C00 - ES * (C02 + ES * (C04 + ES * (C06 + ES * C08))))
#define EN1	(ES * (C22 - ES * (C04 + ES * (C06 + ES * C08))))
#define EN2	(ES * ES * (C44 - ES * (C46 + ES * C48)))
#define EN3	(ES * ES * ES * (C66 - ES * C68))
#define EN4	(ES * ES * ES * ES * C88)

// 緯度経度を横メルカトル(Transverse Marcator)座標に変換して２点間の距離を計算
//
// 入力
//	Lat	: 緯度[radian]
//	Lon	: 経度[radian]
//	clat, clon : 投影原点の緯度経度[radian]
// 出力
//	xTMerc, yTMerc	: 原点からの距離が返る[m]
//
void Rad2TMercWithCenter(double Lat, double Lon, double *xTMerc, double *yTMerc, double clat, double clon)
{
#define EPS 1e-11
	double phi = Lat;
	double lam = Lon - clon;  // 中心の経度のゲタを差っ引く
	double c = cos(phi);
	double al = c * lam;
	double als = al * al;
	double s = sin(phi);
	double ss = s * s;
	double n = ES2 * c * c;
	double cp = cos(clat);
	double sp = sin(clat);
	double ssp = sp*sp;
	double clat_offset = EN0*clat-cp*sp*(EN1+ssp*(EN2+ssp*(EN3+ssp*EN4)));
	double z = EN0 * phi - c * s * (EN1 + ss * (EN2 + ss * (EN3 + ss*EN4))) - clat_offset;
	double t = fabs(c) > EPS ? s/c : 0.0;
	t *= t;
	al /= sqrt(1.0 - ES * s * s);
	*xTMerc = K0 * RE * al * (FC1 + FC3 * als * (1.0 - t + n + FC5 * als * (5.0 + t * (t - 18.0) + n * (14.0 - 58.0 * t)
																			+ FC7 * als * (61.0 + t * (t * (179.0 - t) - 479.0)))));
	*yTMerc = K0 * RE * (z + s * al * lam * FC2 * (1.0 + FC4 * als * (5.0 - t + n * (9.0 + 4.0 * n) +
																	  FC6 * als * (61.0 + t * (t - 58.0) + n * (270.0 - 330.0 * t)
																				   + FC8 * als * (1385.0 + t * (t * (543.0 - t) - 3111.0))))));
#undef EPS
}

// datum conversion
//
#define RE_W 6378137.0			// equatorial radius in [m] @ WGS84
#define FLT_W (1/298.257223)	// oblateness @ WGS84
#define RE_J 6377397.155		// equatorial radius in [m] @ JDG2000
#define FLT_J (1/299.152813)	// oblateness @ JDG2000

/*
 ** WGS84 to Tokyo
 */
void wgs2tokyo(double wgsLat, double wgsLon, double *tkyLat, double *tkyLon)
{
#define E2 (2.0*FLT_W-FLT_W*FLT_W)	// eccentricity e^2
#define BDA (1.0-FLT_W)			// (polar radius) / (equatorial radius)
#define DX 148.0				// shifr offset [m]
#define DY -507.0
#define DZ -681.0
#define DA (RE_J-RE_W)
#define DF (FLT_J-FLT_W)
#define C0 (RE_W*(1.0-E2))
#define C1 (DA*E2/RE_W)
#define C2 (DF/BDA)
#define C3 (DF*BDA)
#define C6 (C1+C3)
    double blat, blon;
    double db, dl;
    double sb, cb, sl, cl, rn, rm;
    blat = MSEC2RAD(wgsLat);
    blon = MSEC2RAD(wgsLon);
    sb = sin(blat);
    cb = cos(blat);
    sl = sin(blon);
    cl = cos(blon);
    rn = 1 / sqrt(1.0 - E2*sb * sb);
    rm = C0 * rn * rn * rn;
    rn *= RE_W;
    // calc offset
    db = (-DX * cl - DY * sl) * sb + (DZ + (C6 * rn + C2 * rm) * sb) * cb;
    db /= rm;
    dl = -DX * sl + DY * cl;
    dl /= rn * cb;
    *tkyLat = RAD2MSEC(blat + db);
    *tkyLon = RAD2MSEC(blon + dl);
#undef E2
#undef BDA
#undef DX
#undef DY
#undef DZ
#undef DA
#undef DF
#undef C0
#undef C1
#undef C2
#undef C3
#undef C6
}

/*
 **  Tokyo to WGS84
 */
void tokyo2wgs(double tkyLat, double tkyLon, double *wgsLat, double *wgsLon)
{
#define E2 (2.0*FLT_J-FLT_J*FLT_J)	// eccentricity e^2
#define BDA (1.0-FLT_J)			// (polar radius) / (equatorial radius)
#define DX -148.0				// shifr offset [m]
#define DY 507.0
#define DZ 681.0
#define DA (RE_W-RE_J)
#define DF (FLT_W-FLT_J)
#define C0 (RE_J*(1.0-E2))
#define C1 (DA*E2/RE_J)
#define C2 (DF/BDA)
#define C3 (DF*BDA)
#define C4 (DA*RE_J)
#define C5 (DF * BDA)
#define C6 (C1+C3)
    double blat, blon;
    double db, dl;
    double sb, cb, sl, cl, rn, rm;
    blat = MSEC2RAD(tkyLat);
    blon = MSEC2RAD(tkyLon);
    sb = sin(blat);
    cb = cos(blat);
    sl = sin(blon);
    cl = cos(blon);
    rn = 1 / sqrt(1.0 - E2*sb * sb);
    rm = C0 * rn * rn * rn;
    rn *= RE_J;
    // calc offset
    db = (-DX * cl - DY * sl) * sb + (DZ + (C6 * rn + C2 * rm) * sb) * cb;
    db /= rm;
    dl = -DX * sl + DY * cl;
    dl /= rn * cb;
    *wgsLat = RAD2MSEC(blat + db);
    *wgsLon = RAD2MSEC(blon + dl);
#undef E2
#undef BDA
#undef DX
#undef DY
#undef DZ
#undef DA
#undef DF
#undef C0
#undef C1
#undef C2
#undef C3
#undef C6
}
