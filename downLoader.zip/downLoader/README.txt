A. build and run
================
this sample project is tested w/
- xcode 8.3.3
- iphone6+/iOS9.3.3 and iphone7+/iOS10.3.1

Note just downloading files runs on simulator, but if you want to test relaunch, you must use real device.

B. how this app works
=====================
1. at app's launch, create download file list from files, 1921 files in total, ~56MB. the download files are located in a server managed by Geospatial Information Authority of Japan (GSI) [http://www.gsi.go.jp/ENGLISH/index.html].
2. begin background task, create url session and tasks, request download to OS create list of task IDs. set download file directory and file name to taskDescription.
3. when all of requests are handed to OS, create flag file (downloadFlag.dat). (The contents of file is not used w/ the sample.)
4. when file downloaded (didFinishDownloadingTo), see if file exists, and see if in the task ID list, then move to download directory with name in taskDescription. the download directory is Library/Caches/download/6..9
5. at didCompleteWithError, see if in task ID list and not duplicated, and updated remained file count (remainedCount). if it gets zero, all done, cancel session, reset to initial state, and let user know (doUpdateUI).

below for relaunch.
6. when killed by user/os/bug, then relaunch (handleEventsForBackgroundURLSession), calles reincarnation(), and if flag file exists, recreate url session.
7. downloaded files are moved to directory with name in taskDescription. no check ID table (doesn't exist)
8. at didCompleteWithError, do nothing.
9. meanwhile, urlSessionDidFinishEvents is called, and reset to initial state, and let user know.

C. user interface
=================
You can modify the operation above by setting switches. I describe below on UI elements from top to bottom.

0. Use mobile (cellular) network
use only wifi if not on. you need to also enable in system setting to use mobile network.

1. Start download / Stop download
as it says.

2. Notify bkgnd task expiration
when background task expired, fire local notification.

3. Notify completion w/o flag file
notify user of the download completion even if flag file is missing. "completion" involves both success and error.

4. Create session w/o flag file
at relaunch, bypass to check flag file existence and create url session anyway. if notify completion w/o flag file is off, no notification to user, and results in memory waste. you can check if process exists or not w/ xcode Debug-Attach to Process menu: downLoader should be at top if it exists.

5. Emulate bkgnd task expiration in 5sec
use like this. "Start download", "Emulate bkgnd task expiration in 5sec", then put home button to put the app in background. it calles application.endBackgroundTask and suspend further download requests. if "Notify bkgnd task expiration" is on, you will see local notification.

6. Crash App in 5 sec
don't run the app w/o xcode, instead, run from launcher screen. then, "Start download", "Crash App in 4 sec", then put home button. The app does long lval = *((long *)1); and dies. If download requests have been accepted, the app relaunches. To handle recreate url session, you need to set "Create session w/o flag file" is on OR tap "Create flag file NOW" before home button.

7. Create flag file NOW
flag file is created after the all of download requests are passed to OS. you can create the flag file NOW with this. usefull before crashing app OR manually terminating the app from task switcher.

8.Don'd delete flag file at exit by user
when user terminates the app, flag file is deleted, so at relaunch no url session is recreated. if this switch is on, don't delete flag file at applicationWillTerminate.

9. Delete downloaded files
delete all of downloaded PNG files.

10. Clear log file
as it says. lots of logging are put in a file logging.txt, which is at Documents directory. you can download to PC w/ iTunes.

11. Show log file
as it says. w/ filter menu you can filter out several logging messages.

D. some other notes
===================
since this sample app is based on the on-going real app development, there are non-essential/unrelated codes. I didn't spend much time to make it clean enough. those non-essential programs are put in "Supporting Files" group of xcode file list pane.
they may include language that you can't read, but pls disregard.
